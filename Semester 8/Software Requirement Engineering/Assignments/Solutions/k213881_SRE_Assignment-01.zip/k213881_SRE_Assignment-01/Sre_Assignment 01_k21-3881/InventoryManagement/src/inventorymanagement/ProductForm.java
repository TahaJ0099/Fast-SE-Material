
package inventorymanagement;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ProductForm extends JFrame {
    private JTextField nameField, priceField, quantityField;
    private JButton addButton, viewButton;
    private List<Product> productList = new ArrayList<>();

    public ProductForm() {
        setTitle("Product Management");
        setSize(400, 300);
        setLayout(new FlowLayout());

        nameField = new JTextField(10);
        priceField = new JTextField(10);
        quantityField = new JTextField(10);
        addButton = new JButton("Add Product");
        viewButton = new JButton("View Products");

        add(new JLabel("Name:"));
        add(nameField);
        add(new JLabel("Price:"));
        add(priceField);
        add(new JLabel("Quantity:"));
        add(quantityField);
        add(addButton);
        add(viewButton);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Product product = new Product(nameField.getText(), Double.parseDouble(priceField.getText()), Integer.parseInt(quantityField.getText()));
                productList.add(product);
                saveProducts();
                JOptionPane.showMessageDialog(null, "Product Added!");
            }
        });

        viewButton.addActionListener(e -> new ProductList().setVisible(true));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void saveProducts() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("inventory.txt", true))) {
            for (Product product : productList) {
                writer.write(product.formatForFile());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}
