
package inventorymanagement;

import java.io.FileWriter;
import java.io.IOException;

public class Logger {
    public static void log(String message) {
        try (FileWriter writer = new FileWriter("log.txt", true)) {
            writer.write(message + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
