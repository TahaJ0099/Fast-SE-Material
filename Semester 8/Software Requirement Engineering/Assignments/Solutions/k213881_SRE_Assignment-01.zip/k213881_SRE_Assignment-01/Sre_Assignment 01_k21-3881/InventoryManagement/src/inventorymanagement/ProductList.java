
package inventorymanagement;



import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ProductList extends JFrame {
    public ProductList() {
        setTitle("Product List");
        setSize(300, 200);
        setLayout(new FlowLayout());

        JTextArea textArea = new JTextArea(10, 20);
        for (Product product : loadProducts()) {
            textArea.append(product.name + " - $" + product.price + " (" + product.quantity + ")\n");
        }
        add(new JScrollPane(textArea));

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    private List<Product> loadProducts() {
        List<Product> products = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("inventory.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                products.add(new Product(data[0], Double.parseDouble(data[1]), Integer.parseInt(data[2])));
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return products;
    }
}

