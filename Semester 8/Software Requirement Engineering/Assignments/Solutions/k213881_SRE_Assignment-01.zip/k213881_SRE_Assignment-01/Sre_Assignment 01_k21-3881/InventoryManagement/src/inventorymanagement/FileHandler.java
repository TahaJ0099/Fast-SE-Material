
package inventorymanagement;


import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileHandler {
    public static void writeToFile(List<Product> products) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("inventory.txt"))) {
            for (Product product : products) {
                writer.write(product.formatForFile());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
    }

    public static List<Product> readFromFile() {
        List<Product> products = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("inventory.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                products.add(new Product(data[0], Double.parseDouble(data[1]), Integer.parseInt(data[2])));
            }
        } catch (IOException e) {
            System.out.println("File error: " + e.getMessage());
        }
        return products;
    }
}

