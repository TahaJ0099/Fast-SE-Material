
package inventorymanagement;


import java.util.List;

public class ProductService {
    public void saveProduct(Product product) {
        List<Product> products = FileHandler.readFromFile();
        products.add(product);
        FileHandler.writeToFile(products);
    }

    public List<Product> fetchProducts() {
        return FileHandler.readFromFile();
    }
}
