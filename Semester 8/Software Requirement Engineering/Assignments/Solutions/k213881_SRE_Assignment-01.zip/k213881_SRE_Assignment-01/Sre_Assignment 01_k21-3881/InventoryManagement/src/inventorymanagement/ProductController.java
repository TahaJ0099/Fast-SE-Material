
package inventorymanagement;

import java.util.List;

public class ProductController {
    private List<Product> products;

    public ProductController(List<Product> products) {
        this.products = products;
    }

    public void addProduct(String name, double price, int quantity) {
        if (ValidationHelper.isPositiveNumber(price) && quantity > 0) {
            Product product = new Product(name, price, quantity);
            products.add(product);
            FileHandler.writeToFile(products);
            Logger.log("Product added: " + name);
        } else {
            Logger.log("Invalid product data: " + name);
        }
    }

    public List<Product> getProducts() {
        return FileHandler.readFromFile();
    }
}
