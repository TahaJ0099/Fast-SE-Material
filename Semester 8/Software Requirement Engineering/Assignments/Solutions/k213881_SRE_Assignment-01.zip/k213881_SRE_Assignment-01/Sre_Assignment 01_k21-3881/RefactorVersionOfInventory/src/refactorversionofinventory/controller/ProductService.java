
package refactorversionofinventory.controller;


import refactorversionofinventory.model.Product;
import refactorversionofinventory.utils.FileHandler;
import java.util.ArrayList;
import java.util.List;

public class ProductService {
    private List<Product> products = new ArrayList<>();

    public ProductService() {
        loadProducts();
    }

    private void loadProducts() {
        List<String> lines = FileHandler.readFile();
        for (String line : lines) {
            String[] data = line.split(",");
            products.add(new Product(data[0], Double.parseDouble(data[1]), Integer.parseInt(data[2])));
        }
    }

    public void addProduct(Product product) {
        products.add(product);
        saveProducts();
    }

    private void saveProducts() {
        List<String> lines = new ArrayList<>();
        for (Product product : products) {
            lines.add(product.toString());
        }
        FileHandler.writeFile(lines);
    }

    public List<Product> getProducts() {
        return products;
    }
}

