
package refactorversionofinventory.view;


import refactorversionofinventory.model.Product;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ProductList extends JFrame {
    public ProductList(List<Product> products) {
        setTitle("Product List");
        setSize(300, 200);
        setLayout(new FlowLayout());

        JTextArea textArea = new JTextArea(10, 20);
        for (Product product : products) {
            textArea.append(product.getName() + " - $" + product.getPrice() + " (" + product.getQuantity() + ")\n");
        }
        add(new JScrollPane(textArea));

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}


