
package refactorversionofinventory.view;



import refactorversionofinventory.controller.ProductController;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProductForm extends JFrame {
    private JTextField nameField, priceField, quantityField;
    private JButton addButton, viewButton;
    private ProductController controller;

    public ProductForm() {
        setTitle("Product Management");
        setSize(400, 300);
        setLayout(new FlowLayout());

        controller = new ProductController();

        nameField = new JTextField(10);
        priceField = new JTextField(10);
        quantityField = new JTextField(10);
        addButton = new JButton("Add Product");
        viewButton = new JButton("View Products");

        add(new JLabel("Name:"));
        add(nameField);
        add(new JLabel("Price:"));
        add(priceField);
        add(new JLabel("Quantity:"));
        add(quantityField);
        add(addButton);
        add(viewButton);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.addProduct(nameField.getText(), Double.parseDouble(priceField.getText()), Integer.parseInt(quantityField.getText()));
                JOptionPane.showMessageDialog(null, "Product Added!");
            }
        });

        viewButton.addActionListener(e -> new ProductList(controller.getAllProducts()).setVisible(true));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

