
package refactorversionofinventory.utils;



public class ValidationHelper {
    public static boolean isPositiveNumber(double number) {
        return number > 0;
    }
}
