
package refactorversionofinventory;

import refactorversionofinventory.view.ProductForm;
public class RefactorVersionOfInventory {


    public static void main(String[] args) {
        new ProductForm().setVisible(true);
    }
    
}
