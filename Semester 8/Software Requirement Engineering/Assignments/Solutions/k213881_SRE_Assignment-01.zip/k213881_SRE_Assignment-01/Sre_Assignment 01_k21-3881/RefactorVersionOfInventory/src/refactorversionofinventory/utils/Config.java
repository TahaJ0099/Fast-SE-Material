
package refactorversionofinventory.utils;


public class Config {
    public static final String FILE_PATH = "inventory.txt";
}


