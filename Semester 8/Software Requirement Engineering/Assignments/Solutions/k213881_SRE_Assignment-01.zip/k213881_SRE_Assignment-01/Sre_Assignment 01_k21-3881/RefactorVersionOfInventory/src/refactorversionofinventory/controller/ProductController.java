
package refactorversionofinventory.controller;


import refactorversionofinventory.model.Product;
import refactorversionofinventory.service.ProductService;
import java.util.List;

public class ProductController {
    private ProductService productService;

    public ProductController() {
        this.productService = new ProductService();
    }

    public void addProduct(String name, double price, int quantity) {
        productService.addProduct(new Product(name, price, quantity));
    }

    public List<Product> getAllProducts() {
        return productService.getProducts();
    }
}

