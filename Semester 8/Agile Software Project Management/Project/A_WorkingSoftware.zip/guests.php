<!DOCTYPE html>
<html lang="en">
<?php
session_start();
require_once 'db_connect.php';
$db = new Database();
$db = $db->conn;  
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guest Management - Receptionist Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
    <style>
        .dashboard-item {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            text-decoration: none;
            padding: 20px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .dashboard-item:hover {
            transform: translateY(-5px);
        }

        .dashboard-item-icon {
            flex: 0 0 auto;
        }

        .dashboard-item-info {
            flex: 1 1 auto;
            margin-left: 20px;
        }

        .dashboard-item-info span {
            display: block;
            margin-bottom: 5px;
        }

        #sidebar{
            z-index: 10;
        }
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 0;
            display: none;
        }
        .overlay.visible {
            display: block;
        }
    </style>
</head>

<body class="bg-cover bg-fixed backdrop-blur-lg bg-center" style="background-image: url('login.jpeg')" contenteditable="false">
    <div class="p-6">
    <?php include "navbar.php"; ?>
    </div>
    <?php include "receptionist_sidebar.php"; ?>
    <main class="flex-1 p-4">
        
        <!-- Overlay -->
        <div class="overlay"></div>

        <!-- Page Content -->
        <div class="py-10">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-gradient-to-t from-slate-400 to-zinc-100 overflow-hidden shadow-sm sm:rounded-3xl">
                    <div class="p-10 border-b border-gray-200">
                        <h1 class="font-extrabold text-5xl text-gray-800 mb-16">Guest Management</h1>
                        <div id="AddGuestDiv" class="shadow-gray-600 cursor-pointer shadow-xl flex justify-start rounded-3xl w-2/3 dashboard-item mb-8 bg-slate-900 hover:bg-gradient-to-r from-transparent to-fuchsia-950">
                            <div class="dashboard-item-icon">
                                <img src="https://www.svgrepo.com/show/474281/add.svg" class="h-16 w-16 text-white" alt="Add Icon">
                            </div>
                            <h2 class="font-bold text-3xl mt-4 text-white ml-4 mb-4">Add new guest</h2>
                        </div>
                        <div id="addGuest" class="hidden overflow-hidden p-3 cursor-pointer rounded-3xl transition-height duration-500 shadow-gray-600 shadow-xl mb-8 bg-gray-900 ">
                            <!-- Add New Guest Form -->
                            <form id="add-form" class="p-6">
                                <input type="hidden" name="action" value="add">
                                <!-- Input fields for guest details -->
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                    <div class="flex flex-col">
                                        <label for="firstname" class="text-white font-bold text-lg mb-2">First Name</label>
                                        <input type="text" id="firstname" name="firstname" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter first name">
                                        <span id="firstname-error" class="text-red-500"></span>
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="lastname" class="text-white font-bold text-lg mb-2">Last Name</label>
                                        <input type="text" id="lastname" name="lastname" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter last name">
                                        <span id="lastname-error" class="text-red-500"></span>
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="email" class="text-white font-bold text-lg mb-2">Email</label>
                                        <input type="email" id="email" name="email" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter email">
                                        <span id="email-error" class="text-red-500"></span>
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="phone" class="text-white font-bold text-lg mb-2">Phone Number</label>
                                        <input type="text" id="phone" name="phone" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter phone number">
                                        <span id="phone-error" class="text-red-500"></span>
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="address" class="text-white font-bold text-lg mb-2">Address</label>
                                        <input type="text" id="address" name="address" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter address">
                                        <span id="address-error" class="text-red-500"></span>
                                    </div>
                                </div>
                                <button type="submit" class="mt-6 bg-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-600 transition duration-300">Add Guest</button>
                            </form>
                            <div id="add-save-success" class="absolute top-1/2 left-1/2 transform -translate-x-1/2 w-72 h-30 justify-center items-center z-70 gap-5 p-4 rounded-2xl bg-slate-800 text-white hidden transition-all duration-1000">
                                <img src="https://www.svgrepo.com/show/410398/check.svg" class="w-16 h-16" alt="Successful svg">
                                <h3 class="font-semibold text-lg">Changes recorded successfully</h3>
                            </div>
                        </div>
                        <!-- Modal Container -->
                        <div id="modal" class="absolute inset-0 z-50 w-full h-full items-center justify-center bg-gray-900 bg-opacity-50 backdrop-blur-lg hidden">
                            <!-- Modal Content -->
                            <div id="save-success" class="absolute bottom-24 left-1/2 transform -translate-x-1/2 w-72 h-30 justify-center items-center z-70 gap-5 p-4 rounded-2xl bg-slate-800 text-white hidden transition-all duration-1000">
                                <img src="https://www.svgrepo.com/show/410398/check.svg" class="w-16 h-16" alt="Successful svg">
                                <h3 class="font-semibold text-lg">Changes recorded successfully</h3>
                            </div>
                            <div id="edit-div" class="bg-gray-900 p-8 rounded-3xl shadow-md">
                                <!-- Edit Form -->
                                <div class="flex justify-end">
                                    <button id="closeModal" class=" bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-2 rounded-lg"><img class="w-8 h-8" src="https://www.svgrepo.com/show/438388/close.svg" alt="close icon"></button>
                                </div>
                                <form id="edit-form" class="p-6">
                                    <input type="hidden" name="action" value="edit">
                                    <input type="hidden" id="edit-guest-id" name="guestId" value="">
                                    <span id="edit-guestId-error" class="text-red-500 hidden"></span>
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                        <div class="flex flex-col">
                                            <label for="edit-firstname" class="text-white font-bold text-lg mb-2">First Name</label>
                                            <input type="text" id="edit-firstname" name="firstname" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter first name">
                                            <span id="edit-firstname-error" class="text-red-500"></span>
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="edit-lastname" class="text-white font-bold text-lg mb-2">Last Name</label>
                                            <input type="text" id="edit-lastname" name="lastname" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter last name">
                                            <span id="edit-lastname-error" class="text-red-500"></span>
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="edit-email" class="text-white font-bold text-lg mb-2">Email</label>
                                            <input type="email" id="edit-email" name="email" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter email">
                                            <span id="edit-email-error" class="text-red-500"></span>
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="edit-phone" class="text-white font-bold text-lg mb-2">Phone Number</label>
                                            <input type="text" id="edit-phone" name="phone" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter phone number">
                                            <span id="edit-phone-error" class="text-red-500"></span>
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="edit-address" class="text-white font-bold text-lg mb-2">Address</label>
                                            <input type="text" id="edit-address" name="address" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter address">
                                            <span id="edit-address-error" class="text-red-500"></span>
                                        </div>
                                    </div>
                                    <button type="submit" class="mt-6 bg-green-500 text-white font-bold py-3 px-3 rounded-lg hover:bg-green-600 transition duration-200">Save changes</button>
                                </form>
                            </div>
                        </div>
                        <h2 class="font-bold text-3xl mt-16 text-gray-800 mb-4">Existing Guests</h2>
                        <!-- Existing Guests -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <?php
                            $query = "SELECT * FROM guests";
                            $result = $db->query($query);

                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) { ?>
                                    <div class="dashboard-item shadow-gray-400 shadow-xl text-white hover:text-gray-900 mb-2 bg-slate-900 border border-gray-400 hover:border-slate-200 hover:bg-gray-300 rounded-2xl p-6 flex flex-col items-center justify-center transition duration-300">
                                        <h2 class="text-lg font-semibold"><?php echo $row["FirstName"] . " " . $row["LastName"]; ?></h2>
                                        <h3 class="text-sm font-bold">Record ID: <?php echo $row["GuestID"]; ?></h3>
                                        <p class="text-sm"><?php echo $row["Email"]; ?></p>
                                        <button onclick="openModal(<?php echo htmlspecialchars(json_encode($row)); ?>)" class="mt-4 bg-blue-500 text-white font-bold py-2 px-4 rounded-lg">Edit</button>
                                    </div>
                                <?php }
                            } else {
                                echo "<p>No guests found.</p>";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    
    <footer class="bg-black border-t h-18 border-gray-700">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <p class="text-center text-sm text-gray-100">© 2024 Lodgify All rights reserved.</p>
        </div>
    </footer>

    <script>
        function EditFormPositioning() {
            const reservationDiv = document.getElementById("edit-div");
            reservationDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        document.addEventListener('DOMContentLoaded', function() {
            const closeSidebarToggle = document.getElementById('closeSidebar');
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const overlay = document.querySelector('.overlay');

            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
                overlay.classList.toggle('visible');
            });
            
            closeSidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
                overlay.classList.toggle('visible');
            });

            const addGuestDiv = document.getElementById('AddGuestDiv');
            const addGuestForm = document.getElementById('addGuest');

            addGuestDiv.addEventListener('click', function() {
                addGuestForm.classList.toggle('hidden');
                document.getElementById('firstname-error').textContent = "";
                document.getElementById('lastname-error').textContent = "";
                document.getElementById('email-error').textContent = "";
                document.getElementById('phone-error').textContent = "";
                document.getElementById('address-error').textContent = "";
            });
        });

        function openModal(guest) {
            document.getElementById('modal').classList.remove('hidden');
            document.getElementById('modal').classList.add('flex');
            document.getElementById('edit-firstname').value = guest.FirstName;
            document.getElementById('edit-lastname').value = guest.LastName;
            document.getElementById('edit-email').value = guest.Email;
            document.getElementById('edit-phone').value = guest.Phone;
            document.getElementById('edit-address').value = guest.Address;
            document.getElementById('edit-guest-id').value = guest.GuestID;
            EditFormPositioning();
        }

        function closeModal() {
            document.getElementById('modal').classList.add('hidden');
            document.getElementById('modal').classList.remove('flex');
            document.getElementById('edit-firstname-error').textContent = "";
            document.getElementById('edit-lastname-error').textContent = "";
            document.getElementById('edit-email-error').textContent = "";
            document.getElementById('edit-phone-error').textContent = "";
            document.getElementById('edit-address-error').textContent = "";
        }

        // Form submission handlers
        document.getElementById("add-form").addEventListener("submit", function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            submitForm(formData, "guest_management_backend.php", "add");
        });

        document.getElementById("edit-form").addEventListener("submit", function(event) {
            event.preventDefault();
            const formData = new FormData(this);
            submitForm(formData, "guest_management_backend.php", "edit");
        });

        function submitForm(formData, url, formType) {
            fetch(url, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                console.log(data); // Debugging
                if (data.errors) {
                    // Handle errors
                    for (const field in data.errors) {
                        const errorElement = document.getElementById(`${formType === 'edit' ? 'edit-' : ''}${field}-error`);
                        if (errorElement) {
                            errorElement.textContent = data.errors[field];
                        }
                    }
                } else if (data.success) {
                    // Show success message
                    const successElement = document.getElementById(
                        formType === 'edit' ? 'save-success' : 'add-save-success'
                    );
                    successElement.classList.remove('hidden');
                    successElement.classList.add('flex');
                    
                    // Close modal and reload after delay
                    setTimeout(() => {
                        successElement.classList.add('hidden');
                        successElement.classList.remove('flex');
                        
                        if (formType === 'edit') {
                            closeModal();
                        } else {
                            // For add form, collapse the form section
                            document.getElementById('addGuest').classList.add('hidden');
                        }
                        
                        // Reload the page after 1 second
                        setTimeout(() => {
                            location.reload();
                        }, 500);
                    }, 1500);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again.');
            });
        }

        document.getElementById('closeModal').addEventListener('click', closeModal);
    </script>
</body>
</html>