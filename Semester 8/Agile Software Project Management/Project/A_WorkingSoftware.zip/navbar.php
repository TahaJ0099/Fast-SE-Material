<!-- Navbar -->
<nav class="bg-slate-300 rounded-3xl h-24 flex items-center justify-between">
    <!-- Logo -->
    <div class="ml-5 w-20 h-20 rounded-full overflow-hidden flex items-center justify-center text-center">
        <img src="logo.jpeg" alt="logo" class="w-14 h-14 rounded-full">
    </div>

    <!-- Sidebar Toggle Button -->
    <div class="flex justify-end mb-2 md:hidden">
        <button class="text-white focus:outline-none " id="sidebarToggle">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
            </svg>  
        </button>
    </div>
    <!-- Navigation Links -->
    <ul class="hidden md:flex space-x-6 mr-8">
        <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
        <?php
            if ($_SESSION["role"] === "Admin") {
                echo '<a href="admin_dashboard.php" class="font-semibold text-center text-xl">Home</a>';
            } else {
                echo '<a href="/we/receptionist_dashboard.php" class="font-semibold text-center text-xl">Home</a>';
            }
        ?>

        </li>
        <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
            <a href="guests.php" class="font-semibold text-xl text-center">Guests</a>
        </li>
        <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
            <a href="reservation.php" class="font-semibold text-xl">Reservations</a>
        </li>
        <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
            <a href="billing.php" class="font-semibold text-xl">Bills</a>
        </li>
        <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
            <a href="rooms.php" class="font-semibold text-xl">Rooms</a>
        </li>
    </ul>

    <!-- Logout Button -->
    <a href="logoutBackend.php" class="mr-5 block p-3 rounded-2xl bg-red-500 text-center text-lg justify-center text-white font-semibold hover:bg-red-600">Logout</a>
</nav>
