<?php
require_once 'db_connect.php';

class ServiceManager {
    private $db;

    public function __construct($dbConn) {
        $this->db = $dbConn;
    }

    public function getServices($reservation_id) {
        if (!$reservation_id) {
            echo json_encode(["error" => "Reservation ID is not provided."]);
            return;
        }
        $sql = "SELECT s.ServiceID, s.ServiceName, rs.TotalPrice 
                FROM reservationservices rs
                JOIN roomservices s ON rs.ServiceID = s.ServiceID
                WHERE rs.ReservationID = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $reservation_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $services = [];
        while ($row = $result->fetch_assoc()) {
            $services[] = $row;
        }
        $stmt->close();
        echo json_encode($services);
    }
}

// Controller logic
$dbObj = new Database();
$serviceManager = new ServiceManager($dbObj->conn);

if (isset($_GET["reservation_id"])) {
    $serviceManager->getServices($_GET["reservation_id"]);
} else {
    echo json_encode(["error" => "Reservation ID is not provided."]);
}
?>
