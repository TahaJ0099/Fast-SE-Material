<?php
require_once 'db_connect.php'; // Ensure this returns a $db connection or a Database class as in previous OOP refactors
$db = new Database();
$db = $db->conn;

class BillingManager {
    private $db;

    public function __construct($dbConn) {
        $this->db = $dbConn;
    }

    public function sanitize($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    public function calculateStayDuration($checkInDate, $checkOutDate) {
        $checkInDateTime = new DateTime($checkInDate);
        $checkOutDateTime = new DateTime($checkOutDate);
        $interval = $checkInDateTime->diff($checkOutDateTime);
        $durationInDays = $interval->days;
        return $durationInDays === 0 ? 1 : $durationInDays;
    }

    public function insertService($reservationID, $serviceID, $serviceCharge) {
        $stmt = $this->db->prepare("INSERT INTO reservationservices (ReservationID, ServiceID, TotalPrice) VALUES (?, ?, ?)");
        $stmt->bind_param("iid", $reservationID, $serviceID, $serviceCharge);
        $stmt->execute();
        $stmt->close();
    }

    public function updateBill($data) {
        $reservationID = $this->sanitize($data["reservationID"]);
        $paymentStatus = $this->sanitize($data["paymentStatus"]);
        $totalAmount = 0;

        // Fetch reservation details
        $reservationStmt = $this->db->prepare("SELECT CheckInDate, CheckOutDate FROM reservations WHERE ReservationID = ?");
        $reservationStmt->bind_param("i", $reservationID);
        $reservationStmt->execute();
        $reservationResult = $reservationStmt->get_result();
        $reservationData = $reservationResult->fetch_assoc();
        $reservationStmt->close();

        $stayDuration = $this->calculateStayDuration($reservationData["CheckInDate"], $reservationData["CheckOutDate"]);

        // Fetch service prices
        $serviceCharges = [];
        $servicesResult = $this->db->query("SELECT ServiceID, Price FROM roomservices");
        while ($row = $servicesResult->fetch_assoc()) {
            $serviceCharges[$row["ServiceID"]] = $row["Price"];
        }

        $totalServiceCharge = 0;
        foreach (["Breakfast" => 1, "Laundry" => 2, "RoomCleaning" => 3] as $serviceName => $serviceID) {
            if (!empty($data[$serviceName]) && $data[$serviceName] === "on") {
                $charge = $serviceCharges[$serviceID] * $stayDuration;
                $this->insertService($reservationID, $serviceID, $charge);
                $totalServiceCharge += $serviceCharges[$serviceID];
            }
        }

        // Fetch base amount
        $billStmt = $this->db->prepare("SELECT TotalAmount FROM billing WHERE ReservationID = ?");
        $billStmt->bind_param("i", $reservationID);
        $billStmt->execute();
        $billResult = $billStmt->get_result();
        $billData = $billResult->fetch_assoc();
        $billStmt->close();
        $totalAmount = $billData["TotalAmount"] + $stayDuration * $totalServiceCharge;

        // Update bill
        $stmt = $this->db->prepare("UPDATE billing SET TotalAmount = ?, PaymentStatus = ? WHERE ReservationID = ?");
        $stmt->bind_param("dsi", $totalAmount, $paymentStatus, $reservationID);
        if ($stmt->execute()) {
            echo json_encode(["success" => "Bill updated successfully"]);
        } else {
            echo json_encode(["errors" => ["database" => $this->db->error]]);
        }
        $stmt->close();
    }
}

// Controller logic
$dbObj = new Database();
$billingManager = new BillingManager($dbObj->conn);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $billingManager->updateBill($_POST);
}
?>
