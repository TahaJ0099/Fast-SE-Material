<!DOCTYPE html>
<html lang="en">
<?php
session_start();
require_once 'db_connect.php'; // Ensure this returns a $db connection or a Database class as in previous OOP refactors
$db = new Database();
$db = $db->conn;
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Billing Management - Receptionist Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
    <style>
        .dashboard-item {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            text-decoration: none;
            padding: 20px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .dashboard-item:hover {
            transform: translateY(-5px);
        }

        .dashboard-item-icon {
            flex: 0 0 auto;
        }

        .dashboard-item-info {
            flex: 1 1 auto;
            margin-left: 20px;
        }

        .dashboard-item-info span {
            display: block;
            margin-bottom: 5px;
        }
        /* Style the date input arrow */
        input[type="date"]::-webkit-calendar-picker-indicator {
            filter: invert(1); /* Invert the color to white */
            transform: scale(1.5); /* Increase the size by 20% */
        }

        #sidebar{
            z-index: 10;
        }
        .overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black overlay */
        z-index: 0; /* Place overlay behind other content */
        display: none; /* Initially hidden */
    }
        .overlay.visible {
        display: block; /* Show overlay when explicitly set to visible */
    }
    </style>
</head>

<body class="bg-cover bg-fixed backdrop-blur-lg bg-center" style="background-image: url('login.jpeg')" contenteditable="false">
    <div class="p-6">
    <?php include "navbar.php"; ?>
    </div>
    <?php include "receptionist_sidebar.php"; ?>
    <main class="flex-1 p-4">
        
        <!-- Overlay to add shadow effect when sidebar is opened -->
        <div class="overlay"></div>

        <!-- Page Content -->
        <div class="py-10">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-gradient-to-t from-slate-400 to-zinc-100 overflow-hidden shadow-sm sm:rounded-3xl">
                    <div class="p-10 border-b border-gray-200">
                        <h1 class="font-extrabold text-5xl text-gray-800 mb-16">Billing Management</h1>
                        <div id="addBillingDiv" class="shadow-gray-600 hidden cursor-pointer shadow-xl //flex justify-start rounded-3xl w-2/3 dashboard-item mb-8 bg-slate-900 hover:bg-gradient-to-r from-transparent to-fuchsia-950">
                            <div class="dashboard-item-icon">
                                    <!-- SVG icon -->
                                <img src="https://www.svgrepo.com/show/474281/add.svg" class="h-16 w-16 text-white" alt="Add Icon">
                            </div>
                            <h2 class="font-bold text-3xl mt-4 text-white ml-4 mb-4">Add new reservation</h2>
                        </div>
                        <div id="addReservation" class="hidden overflow-hidden p-3 cursor-pointer rounded-3xl transition-height duration-500 shadow-gray-600 shadow-xl mb-8 bg-gray-900 ">
                            <!-- Add New reservation Form -->
                            <form id="add-form" action="reservation_management_backend.php" method="POST" class="p-6">
                                <input type="text" class="hidden" name="task" value="add">
                                <!-- Input fields for reservation details -->
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                    <div class="flex flex-col">
                                        <label for="GuestID" class="text-white font-bold text-lg mb-2">Guest ID</label>
                                        <input type="text" id="GuestID" name="GuestID" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter guest's ID">
                                        <span id="GuestID-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="RoomID" class="text-white font-bold text-lg mb-2">Room ID</label>
                                        <input type="text" id="RoomID" name="RoomID" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter room's ID">
                                        <span id="RoomID-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="CheckInDate" class="text-white font-bold text-lg mb-2">Check-In Date</label>
                                        <input type="date" id="CheckInDate" name="CheckInDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                        <span id="CheckInDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="CheckOutDate" class="text-white font-bold text-lg mb-2">Check-Out Date</label>
                                        <input type="date" id="CheckOutDate" name="CheckOutDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                        <span id="CheckOutDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="ReservationDate" class="text-white font-bold text-lg mb-2">Reservation Date</label>
                                        <input type="date" id="ReservationDate" readonly value="<?php echo date(
                                            "Y-m-d"
                                        ); ?>" name="ReservationDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                        <span id="ReservationDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <!-- Add more input fields for other reservation details -->
                                </div>
                                <!-- Submit button -->
                                <button type="submit" class="mt-6 bg-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-600 transition duration-300">Add Reservation</button>
                            </form>

                            <div id="add-save-success" class="absolute top-2/5 left-1/2 transform -translate-x-1/2 w-72 h-30 justify-center hidden items-center z-70 gap-5 p-4 rounded-2xl bg-slate-800 text-white transition-all duration-1000">
                                <img src="https://www.svgrepo.com/show/410398/check.svg" class="w-16 h-16" alt="Successful svg">
                                <h3 class="font-semibold text-lg">Changes recorded successfully</h3>
                            </div>
                        </div>
                        <!-- Modal Container -->
                        <div id="modal" class="absolute inset-0 z-50 w-full h-full items-center justify-center bg-gray-900 bg-opacity-50 backdrop-blur-lg hidden">
                            <!-- Modal Content -->
                            <div id="save-success" class="absolute bottom-1/4 left-1/2 transform -translate-x-1/2 w-72 h-30 justify-center items-center z-70 gap-5 p-4 rounded-2xl bg-slate-800 text-white hidden transition-all duration-1000">
                                <img src="https://www.svgrepo.com/show/410398/check.svg" class="w-16 h-16" alt="Successful svg">
                                <h3 class="font-semibold text-lg">Changes recorded successfully</h3>
                            </div>
                            <div id="edit-div" class="bg-gray-900 p-8 rounded-3xl shadow-md">
                                <!-- Edit Form -->
                                <div class="flex justify-end">
                                    <!-- Close Button -->
                                    <button id="closeModal" class=" bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-2 rounded-lg"><img class="w-8 h-8" src="https://www.svgrepo.com/show/438388/close.svg" alt="close icon"></button>
                                </div>
                                <form id="edit-form" action="billing_management_backend.php" method="POST" class="p-6">
                                    <input type="hidden" name="task" value="edit">
                                    <input type="hidden" id="edit-billingID" name="BillingID" value="">
                                    <span id="edit-BillingID-error" class="text-red-500 hidden"></span><!-- Error message placeholder -->
                                    <!-- Input fields for reservation details -->
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                        <div class="flex flex-col">
                                            <label for="ReservationID" class="text-white font-bold text-lg mb-2">Reservation ID</label>
                                            <input type="text" id="edit-ReservationID" name="ReservationID" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter guest's ID">
                                            <span id="edit-ReservationID-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="TotalAmount" class="text-white font-bold text-lg mb-2">Total Amount</label>
                                            <input type="text" id="edit-TotalAmount" name="TotalAmount" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter room ID">
                                            <span id="edit-TotalAmount-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="PaymentStatus" class="text-white font-bold text-lg mb-2">Payment Status</label>
                                            <select id="edit-PaymentStatus" name="PaymentStatus" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                                <option value="Paid">Paid</option>
                                                <option value="Unpaid">Unpaid</option>
                                            </select>
                                            <span id="edit-Status-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                        <div class="flex ">
                                            <label for="ServicesDiv" class="text-white font-bold text-xl mb-2">Services</label>
                                            <input class="ml-2 mb-1" type="checkbox" name="ServicesDiv" style="transform: scale(1.5); margin-right: 5px;" onchange="toggleServicesDiv()" id="ServicesDivCheckbox">
                                        </div>  
                                    </div>
                                    <div id="services" class="hidden grid-cols-1 md:grid-cols-3 gap-6">
                                        <?php
                                        // Fetch existing services from the database
                                        $servicesQuery =
                                            "SELECT * FROM roomservices";
                                        $servicesResult = $db->query(
                                            $servicesQuery
                                        );

                                        // Check if there are any bills
                                        if ($servicesResult->num_rows > 0) {
                                            // Loop through each bill
                                            while (
                                                $Row = $servicesResult->fetch_assoc()
                                            ) {

                                                // Extract bill details
                                                $ServiceID = $Row["ServiceID"];
                                                $ServiceName =
                                                    $Row["ServiceName"];
                                                $Price = $Row["Price"];

                                                // Display details
                                                ?>
                                                        <div class="flex flex-row gap-3 mt-3">
                                                            <label for="<?php echo $ServiceName; ?>" class="text-white font-bold text-lg mb-2"><?php echo $ServiceName; ?></label>
                                                            <input class="ml-2 mb-1" type="checkbox" id="edit-<?php echo $ServiceName; ?>" name="<?php echo $ServiceName; ?>" style="transform: scale(1.5); margin-right: 5px;">
                                                            <span id="edit-<?php echo $ServiceName; ?>" class="text-green-500 text-lg mb-1">$<?php echo $Price; ?></span><!-- Price message placeholder -->
                                                        </div>
                                                        <?php
                                            }
                                        } else {
                                            // No services found
                                            echo "<p>No services found.</p>";
                                        }
                                        ?>
                                        
                                    </div>
                                    <!-- Submit button -->
                                    <button type="submit" class="mt-6 bg-green-500 text-white font-bold py-3 px-3 rounded-lg hover:bg-green-600 transition duration-200">Save changes</button>
                                    
                                </form>
                                <!-- </form> -->
                            </div>
                        </div>
                        <h1 class="font-bold text-3xl mt-16 text-gray-800 mb-8">Existing Bills</h1>
                        <!-- Existing bills -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <?php
                            // Fetch existing bills from the database
                            $billQuery = "SELECT * FROM billing";
                            $billResult = $db->query($billQuery);

                            // Check if there are any bills
                            if ($billResult->num_rows > 0) {
                                // Loop through each bill
                                while ($billRow = $billResult->fetch_assoc()) {

                                    // Extract bill details
                                    $reservationID = $billRow["ReservationID"];
                                    $totalAmount = $billRow["TotalAmount"];
                                    $paymentStatus = $billRow["PaymentStatus"];
                                    $billingDate = $billRow["BillingDate"];

                                    // Display bill details
                                    ?>
                                        <div class="dashboard-item shadow-gray-400 shadow-xl text-white hover:text-gray-900 mb-2 bg-slate-900 border border-gray-400 hover:border-slate-200 hover:bg-gray-300 rounded-2xl p-6 flex flex-col items-center justify-center transition duration-300">
                                            <h2 class="text-lg font-bold">Billing ID: <?php echo $reservationID; ?></h2>
                                            <p class="text-sm">Total Amount: <?php echo $totalAmount; ?></p>
                                            <p class="text-sm">Payment Status: <?php echo $paymentStatus; ?></p>
                                            <p class="text-sm">Billing Date: <?php echo $billingDate; ?></p>

                                            <!-- Edit Button -->
                                            <button onclick="openBillingModal(<?php echo htmlspecialchars(
                                                json_encode($billRow)
                                            ); ?>)" class="mt-4 bg-blue-500 text-white font-bold py-2 px-4 rounded-lg">Edit</button>
                                        </div>
                                        <?php
                                }
                            } else {
                                // No bills found
                                echo "<p>No bills found.</p>";
                            }
                            ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
    

    <!-- Footer -->
    <footer class="bg-black border-t h-18 border-gray-700">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <p class="text-center text-sm text-gray-100">© 2024 Lodgify All rights reserved.</p>
        </div>
    </footer>
    <script>
        function toggleServicesDiv() {
            // Get the checkbox element
            var checkbox = document.getElementById("ServicesDivCheckbox");
            
            // Get the div element to show/hide
            var services = document.getElementById("services");
            
            // If checkbox is checked, show the div; otherwise, hide it
            if (checkbox.checked) {
                services.classList.remove("hidden");
                services.classList.add("grid");
            } else {
                services.classList.add("hidden");
                services.classList.remove("grid");
            }
        }
        function EditFormPositioning() {
            // Get the position of the clicked reservation div
            const reservationDiv = document.getElementById("edit-div");
            reservationDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        document.addEventListener('DOMContentLoaded', function() {
            // Get the sidebar and the sidebar toggle button
            const closeSidebarToggle = document.getElementById('closeSidebar');
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const overlay = document.querySelector('.overlay');

            // Add event listener to toggle button
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
                overlay.classList.toggle('visible'); // Toggle overlay visibility
            });
            closeSidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
                overlay.classList.toggle('visible'); // Toggle overlay visibility
            });
        });
        function openBillingModal(bills) {
            // Open the modal
            document.getElementById('edit-billingID').value = bills.BillingID;
            document.getElementById('modal').classList.remove('hidden');
            document.getElementById('modal').classList.add('flex');
            // fill the reservation ID for billing purposes
            //document.getElementById('ReservationID').value = bills
            // Fill the form fields with the guest's information
            document.getElementById('edit-ReservationID').value = bills.ReservationID;
            document.getElementById('edit-TotalAmount').value = bills.TotalAmount;
            var StatusDropdown  = document.getElementById('edit-PaymentStatus');
            for (var i = 0; i < StatusDropdown.options.length; i++) {
                var option = StatusDropdown.options[i];
                if (option.value === bills.PaymentStatus) {
                    StatusDropdown.options[i].selected = true;
                    break; // Exit the loop once the matching option is found and selected
                }
            }
            // Fetch the list of services availed by the customer
            // Make sure to replace 'get_services.php' with the actual URL of your backend script
            fetch(`get_services.php?reservation_id=${bills.ReservationID}`)
                .then(response => response.json())
                .then(data => {
                    var ServicesCheckbox = document.getElementById("ServicesDivCheckbox");
                    if(!ServicesCheckbox.checked && data.length>0){
                        ServicesCheckbox.checked = true;
                        toggleServicesDiv();
                    }
                    data.forEach(service => {
                        // Find the checkbox element corresponding to the service ID
                        const checkbox = document.querySelector(`input[type=checkbox][id="edit-${service.ServiceName}"]`);
                        if (checkbox) {
                            // Check the checkbox if the service is availed
                            checkbox.checked = true;
                        }
                    });
                })
                .catch(error => console.error('Error:', error));
            EditFormPositioning();
        }

        // Function to close modal
        function closeModal() {
            // Hide the modal
            var modal = document.getElementById('modal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            document.getElementById('edit-BillingID-error').textContent = "";
            document.getElementById('edit-ReservationID-error').textContent = "";
            document.getElementById('edit-TotalAmount-error').textContent = "";
            document.getElementById('edit-Status-error').textContent = "";
            document.getElementById('ServicesDivCheckbox').checked = false;
            toggleServicesDiv();
            document.getElementById('edit-Breakfast').checked = false;
            document.getElementById('edit-Laundry').checked = false;
            document.getElementById('edit-RoomCleaning').checked = false;
        }
        function submitAddForm(formData, actionUrl) {
            // Send form data via AJAX
            //console.log(actionUrl);
            fetch(actionUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                //console.log(data);
                if (data.errors) {
                    // Display errors beneath input fields
                    for (var field in data.errors) {
                        var errorMessage = data.errors[field];
                        document.getElementById(field + "-error").textContent = errorMessage;
                    }
                } else if (data.success) {
                    // Handle success message or take appropriate action
                    document.getElementById("add-save-success").classList.remove('hidden');
                    document.getElementById("add-save-success").classList.add('flex');
                    setTimeout(function() {
                        document.getElementById("add-save-success").classList.add('hidden');
                        document.getElementById("add-save-success").classList.remove('flex');
                        location.reload();
                    }, 1000); // 1000 milliseconds delay
                }
            })
            .catch(error => console.error('Error:', error));
        }
        document.getElementById("add-form").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission

            var formData = new FormData(this); // Serialize form data
            var actionUrl = this.action; // Get form action URL

            // Call the submitForm function
            submitAddForm(formData, actionUrl);
        });
        document.addEventListener('DOMContentLoaded', function() {
            // Get the Add New Guest div
            const addBillingDiv = document.getElementById('addBillingDiv');
            // Get the Add Guest form
            const addReservationForm = document.getElementById('addReservation');

            // Add click event listener to the Add New Guest div
            addBillingDiv.addEventListener('click', function() {
                // Toggle the hidden class on the Add Guest form
                addReservationForm.classList.toggle('hidden');
                // Toggle the max-h-0 and max-h-screen classes on the Add Guest form
                addReservationForm.classList.toggle('max-h-0');
                addReservationForm.classList.toggle('max-h-screen');
                document.getElementById('GuestID-error').textContent = "";
                document.getElementById('RoomID-error').textContent = "";
                document.getElementById('CheckInDate-error').textContent = "";
                document.getElementById('CheckOutDate-error').textContent = "";
                //document.getElementById('address-error').textContent = "";
            });
        });
        function submitForm(formData, actionUrl) {
            // Send form data via AJAX
            console.log(actionUrl);
            fetch(actionUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.errors) {
                    // Display errors beneath input fields
                    for (var field in data.errors) {
                        var errorMessage = data.errors[field];
                        console.log(field);
                        document.getElementById("edit-"+ field + "-error").textContent = errorMessage;
                    }
                } else if (data.success) {
                    // Handle success message or take appropriate action
                    //alert(data.success);
                    document.getElementById("save-success").classList.remove('hidden');
                    document.getElementById("save-success").classList.add('flex');
                    setTimeout(function() {
                        document.getElementById("save-success").classList.add('hidden');
                        document.getElementById("save-success").classList.remove('flex');
                        //alert(data.success);
                        location.reload();
                    }, 1000); // 1000 milliseconds delay
                }
            })
            .catch(error => console.error('Error:', error));
        }
        document.getElementById("edit-form").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission

            var formData = new FormData(this); // Serialize form data
            var actionUrl = this.action; // Get form action URL

            // Call the submitForm function
            submitForm(formData, actionUrl);
        });


        // Close modal when close button is clicked
        var closeModalButton = document.getElementById('closeModal');
        closeModalButton.addEventListener('click', closeModal);
        //document.getElementById("add-save-success").classList.remove('hidden');
        //document.getElementById("save-success").classList.remove('hidden');
    </script>
</body>

</html>
