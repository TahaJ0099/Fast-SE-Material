<!DOCTYPE html>
<html lang="en">
<?php
session_start();
require_once 'db_connect.php'; // Ensure this returns a $db connection or a Database class as in previous OOP refactors
$db = new Database();
$db = $db->conn;
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation Management - Receptionist Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
    <style>
        .dashboard-item {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            text-decoration: none;
            padding: 20px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .dashboard-item:hover {
            transform: translateY(-5px);
        }

        .dashboard-item-icon {
            flex: 0 0 auto;
        }

        .dashboard-item-info {
            flex: 1 1 auto;
            margin-left: 20px;
        }

        .dashboard-item-info span {
            display: block;
            margin-bottom: 5px;
        }
        /* Style the date input arrow */
        input[type="date"]::-webkit-calendar-picker-indicator {
            filter: invert(1); /* Invert the color to white */
            transform: scale(1.5); /* Increase the size by 20% */
        }

        #sidebar{
            z-index: 10;
        }
        .overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black overlay */
        z-index: 0; /* Place overlay behind other content */
        display: none; /* Initially hidden */
    }
        .overlay.visible {
        display: block; /* Show overlay when explicitly set to visible */
    }
    </style>
</head>

<body class="bg-cover bg-fixed backdrop-blur-lg bg-center" style="background-image: url('login.jpeg')" contenteditable="false">
    <div class="p-6">
    <?php include "navbar.php"; ?>
    </div>
    <?php include "receptionist_sidebar.php"; ?>
    <main class="flex-1 p-4">
        
        <!-- Overlay to add shadow effect when sidebar is opened -->
        <div class="overlay"></div>

        <!-- Page Content -->
        <div class="py-10">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-gradient-to-t from-slate-400 to-zinc-100 overflow-hidden shadow-sm sm:rounded-3xl">
                    <div class="p-10 border-b border-gray-200">
                        <h1 class="font-extrabold text-5xl text-gray-800 mb-16">Reservations Management</h1>
                        <div id="addReservationDiv" class="shadow-gray-600 cursor-pointer shadow-xl flex justify-start rounded-3xl w-2/3 dashboard-item mb-8 bg-slate-900 hover:bg-gradient-to-r from-transparent to-fuchsia-950">
                            <div class="dashboard-item-icon">
                                    <!-- SVG icon -->
                                <img src="https://www.svgrepo.com/show/474281/add.svg" class="h-16 w-16 text-white" alt="Add Icon">
                            </div>
                            <h2 class="font-bold text-3xl mt-4 text-white ml-4 mb-4">Add new reservation</h2>
                        </div>
                        <div id="addReservation" class="hidden overflow-hidden p-3 cursor-pointer rounded-3xl transition-height duration-500 shadow-gray-600 shadow-xl mb-8 bg-gray-900 ">
                            <!-- Add New reservation Form -->
                            <form id="add-form" action="reservation_management_backend.php" method="POST" class="p-6">
                                <input type="text" class="hidden" name="action" value="add">
                                <!-- Input fields for reservation details -->
                                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                                    <div class="flex flex-col">
                                        <label for="GuestID" class="text-white font-bold text-lg mb-2">Guest ID</label>
                                        <input type="text" id="GuestID" name="GuestID" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter guest's ID">
                                        <span id="GuestID-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="RoomID" class="text-white font-bold text-lg mb-2">Room ID</label>
                                        <input type="text" id="RoomID" name="RoomID" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter room's ID">
                                        <span id="RoomID-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="CheckInDate" class="text-white font-bold text-lg mb-2">Check-In Date</label>
                                        <input type="date" id="CheckInDate" name="CheckInDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                        <span id="CheckInDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="CheckOutDate" class="text-white font-bold text-lg mb-2">Check-Out Date</label>
                                        <input type="date" id="CheckOutDate" name="CheckOutDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                        <span id="CheckOutDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <div class="flex flex-col">
                                        <label for="ReservationDate" class="text-white font-bold text-lg mb-2">Reservation Date</label>
                                        <input type="date" id="ReservationDate" readonly value="<?php echo date(
                                            "Y-m-d"
                                        ); ?>" name="ReservationDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                        <span id="ReservationDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                    </div>
                                    <!-- Add more input fields for other reservation details -->
                                </div>
                                <!-- Submit button -->
                                <button type="submit" class="mt-6 bg-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-600 transition duration-300">Add Reservation</button>
                            </form>

                            <div id="add-save-success" class="absolute top-2/5 left-1/2 transform -translate-x-1/2 w-72 h-30 justify-center hidden items-center z-70 gap-5 p-4 rounded-2xl bg-slate-800 text-white transition-all duration-1000">
                                <img src="https://www.svgrepo.com/show/410398/check.svg" class="w-16 h-16" alt="Successful svg">
                                <h3 class="font-semibold text-lg">Changes recorded successfully</h3>
                            </div>
                        </div>
                        <!-- Modal Container -->
                        <div id="modal" class="absolute inset-0 z-50 w-full h-full items-center justify-center bg-gray-900 bg-opacity-50 backdrop-blur-lg hidden">
                            <!-- Modal Content -->
                            <div id="save-success" class="absolute bottom-1/4 left-1/2 transform -translate-x-1/2 w-72 h-30 justify-center items-center z-70 gap-5 p-4 rounded-2xl bg-slate-800 text-white hidden transition-all duration-1000">
                                <img src="https://www.svgrepo.com/show/410398/check.svg" class="w-16 h-16" alt="Successful svg">
                                <h3 class="font-semibold text-lg">Changes recorded successfully</h3>
                            </div>
                            <div id = "edit-div" class="bg-gray-900 p-8 relative rounded-3xl shadow-md">
                                <!-- Edit Form -->
                                <div class="flex justify-end">
                                    <!-- Close Button -->
                                    <button id="closeModal" class=" bg-red-500 hover:bg-red-600 text-white font-bold py-2 px-2 rounded-lg"><img class="w-8 h-8" src="https://www.svgrepo.com/show/438388/close.svg" alt="close icon"></button>
                                </div>
                                <form id="edit-form" action="reservation_management_backend.php" method="POST" class="p-6">
                                    <input type="hidden" name="action" value="edit">
                                    <input type="hidden" id="edit-ReservationID" name="ReservationID" value="">
                                    <span id="edit-reservationId-error" class="text-red-500 hidden"></span><!-- Error message placeholder -->
                                    <!-- Input fields for reservation details -->
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                                        <div class="flex flex-col">
                                            <label for="GuestID" class="text-white font-bold text-lg mb-2">Guest ID</label>
                                            <input type="text" id="edit-GuestID" name="GuestID" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter guest's ID">
                                            <span id="edit-GuestID-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="RoomID" class="text-white font-bold text-lg mb-2">Room ID</label>
                                            <input type="text" id="edit-RoomID" name="RoomID" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500" placeholder="Enter room ID">
                                            <span id="edit-RoomID-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="CheckInDate" class="text-white font-bold text-lg mb-2">Check-In Date</label>
                                            <input type="date" id="edit-CheckInDate" name="CheckInDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                            <span id="edit-CheckInDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="CheckOutDate" class="text-white font-bold text-lg mb-2">Check-Out Date</label>
                                            <input type="date" id="edit-CheckOutDate" name="CheckOutDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                            <span id="edit-CheckOutDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="ReservationDate" class="text-white font-bold text-lg mb-2">Reservation Date</label>
                                            <input type="date" id="edit-ReservationDate" name="ReservationDate" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                            <span id="edit-ReservationDate-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                        <div class="flex flex-col">
                                            <label for="Status" class="text-white font-bold text-lg mb-2">Status</label>
                                            <select id="edit-Status" name="Status" class="border-gray-300 text-gray-300 focus:text-white rounded-lg p-3 focus:outline-none bg-slate-800 focus:bg-slate-950 focus:ring focus:border-blue-500">
                                                <option value="Cancelled">Cancelled</option>
                                                <option value="Checked in">Checked In</option>
                                                <option value="Checked out">Checked Out</option>
                                                <option value="Confirmed">Confirmed</option>
                                            </select>
                                            <span id="edit-Status-error" class="text-red-500"></span><!-- Error message placeholder -->
                                        </div>
                                    </div>
                                    <!-- Submit button -->
                                    <button type="submit" class="mt-6 bg-green-500 text-white font-bold py-3 px-3 rounded-lg hover:bg-green-600 transition duration-200">Save changes</button>
                                </form>
                                <!-- </form> -->
                            </div>
                        </div>
                        <h2 class="font-bold text-3xl mt-16 text-gray-800 mb-4">Existing Reservations</h2>
                        <!-- Existing Guests -->
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <?php
                            // Fetch existing reservations from the database
                            $query = "SELECT * FROM reservations";
                            $result = $db->query($query);

                            // Check if there are any reservations
                            if ($result->num_rows > 0) {
                                // Loop through each reservation
                                while ($row = $result->fetch_assoc()) {

                                    // Extract reservation details
                                    $reservationID = $row["ReservationID"];
                                    $guestID = $row["GuestID"];
                                    $roomID = $row["RoomID"];
                                    $checkInDate = $row["CheckInDate"];
                                    $checkOutDate = $row["CheckOutDate"];
                                    $reservationDate = $row["ReservationDate"];
                                    $status = $row["Status"];

                                    // Query to fetch services availed on this reservation
                                    $servicesQuery = "SELECT s.ServiceName, rs.Quantity, rs.TotalPrice
                                                            FROM reservationservices rs
                                                            INNER JOIN roomservices s ON rs.ServiceID = s.ServiceID
                                                            WHERE rs.ReservationID = $reservationID";
                                    $servicesResult = $db->query(
                                        $servicesQuery
                                    );

                                    // Display reservation details
                                    ?>
                                            <div class="dashboard-item shadow-gray-400 shadow-xl text-white hover:text-gray-900 mb-2 bg-slate-900 border border-gray-400 hover:border-slate-200 hover:bg-gray-300 rounded-2xl p-6 flex flex-col items-center justify-center transition duration-300">
                                                <h2 class="text-lg font-bold">Reservation ID: <?php echo $reservationID; ?></h2>
                                                <p class="text-sm">Guest ID: <?php echo $guestID; ?></p>
                                                <p class="text-sm">Room ID: <?php echo $roomID; ?></p>
                                                <p class="text-sm">Check-In Date: <?php echo $checkInDate; ?></p>
                                                <p class="text-sm">Check-Out Date: <?php echo $checkOutDate; ?></p>
                                                <p class="text-sm">Reservation Date: <?php echo $reservationDate; ?></p>
                                                <p class="text-sm">Status: <?php echo $status; ?></p>
                                                <p class="text-sm font-bold">Services</p>
                                                <?php // Display services availed

                                    if ($servicesResult->num_rows > 0) {
                                                    while (
                                                        $serviceRow = $servicesResult->fetch_assoc()
                                                    ) {
                                                        //echo "<p class='text-sm'>Service: {$serviceRow["ServiceName"]}, Quantity: {$serviceRow["Quantity"]}, Total Price: {$serviceRow["TotalPrice"]}</p>";
                                                        echo "<p class='text-sm'>{$serviceRow["ServiceName"]}</p>";
                                                    }
                                                } else {
                                                    echo "<p>No services availed.</p>";
                                                } ?>

                                                <!-- Edit Button -->
                                                <button onclick="openModal(<?php echo htmlspecialchars(
                                                    json_encode($row)
                                                ); ?>)" class="mt-4 bg-blue-500 text-white font-bold py-2 px-4 rounded-lg">Edit</button>
                                            </div>
                                            <?php
                                }
                            } else {
                                // No reservations found
                                echo "<p>No reservations found.</p>";
                            }
                            ?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>
    

    <!-- Footer -->
    <footer class="bg-black border-t h-18 border-gray-700">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <p class="text-center text-sm text-gray-100">© 2024 Lodgify All rights reserved.</p>
        </div>
    </footer>
    <script>
        function EditFormPositioning() {
            // Get the position of the clicked reservation div
            const reservationDiv = document.getElementById("edit-div");
            reservationDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        document.addEventListener('DOMContentLoaded', function() {
            // Get the sidebar and the sidebar toggle button
            const closeSidebarToggle = document.getElementById('closeSidebar');
            const sidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const overlay = document.querySelector('.overlay');

            // Add event listener to toggle button
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
                overlay.classList.toggle('visible'); // Toggle overlay visibility
            });
            closeSidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
                overlay.classList.toggle('visible'); // Toggle overlay visibility
            });
        });
        function openModal(reservation) {
            // Open the modal
            document.getElementById('modal').classList.remove('hidden');
            document.getElementById('modal').classList.add('flex');
            // Fill the form fields with the guest's information
            document.getElementById('edit-ReservationID').value = reservation.ReservationID;
            document.getElementById('edit-GuestID').value = reservation.GuestID;
            document.getElementById('edit-RoomID').value = reservation.RoomID;
            document.getElementById('edit-CheckInDate').value = reservation.CheckInDate;
            document.getElementById('edit-CheckOutDate').value = reservation.CheckOutDate;
            document.getElementById('edit-ReservationDate').value = reservation.ReservationDate;
            var StatusDropdown  = document.getElementById('edit-Status');
            for (var i = 0; i < StatusDropdown.options.length; i++) {
                var option = StatusDropdown.options[i];
                if (option.value === reservation.Status) {
                    StatusDropdown.options[i].selected = true;
                    break; // Exit the loop once the matching option is found and selected
                }
            }
            EditFormPositioning();
        }

        // Function to close modal
        function closeModal() {
            // Hide the modal
            var modal = document.getElementById('modal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
            document.getElementById('edit-Status-error').textContent = "";
            document.getElementById('edit-GuestID-error').textContent = "";
            document.getElementById('edit-RoomID-error').textContent = "";
            document.getElementById('edit-CheckInDate-error').textContent = "";
            document.getElementById('edit-CheckOutDate-error').textContent = "";
            //document.getElementById('edit-GuestID').textcontent = "";
        }
        function submitAddForm(formData, actionUrl) {
            // Send form data via AJAX
            //console.log(actionUrl);
            fetch(actionUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                //console.log(data);
                if (data.errors) {
                    // Display errors beneath input fields
                    for (var field in data.errors) {
                        var errorMessage = data.errors[field];
                        document.getElementById(field + "-error").textContent = errorMessage;
                    }
                } else if (data.success) {
                    // Handle success message or take appropriate action
                    document.getElementById("add-save-success").classList.remove('hidden');
                    document.getElementById("add-save-success").classList.add('flex');
                    setTimeout(function() {
                        document.getElementById("add-save-success").classList.add('hidden');
                        document.getElementById("add-save-success").classList.remove('flex');
                        location.reload();
                    }, 1000); // 1000 milliseconds delay
                }
            })
            .catch(error => console.error('Error:', error));
        }
        document.getElementById("add-form").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission

            var formData = new FormData(this); // Serialize form data
            var actionUrl = this.action; // Get form action URL

            // Call the submitForm function
            submitAddForm(formData, actionUrl);
        });
        document.addEventListener('DOMContentLoaded', function() {
            // Get the Add New Guest div
            const addReservationDiv = document.getElementById('addReservationDiv');
            // Get the Add Guest form
            const addReservationForm = document.getElementById('addReservation');

            // Add click event listener to the Add New Guest div
            addReservationDiv.addEventListener('click', function() {
                // Toggle the hidden class on the Add Guest form
                addReservationForm.classList.toggle('hidden');
                // Toggle the max-h-0 and max-h-screen classes on the Add Guest form
                addReservationForm.classList.toggle('max-h-0');
                addReservationForm.classList.toggle('max-h-screen');
                document.getElementById('GuestID-error').textContent = "";
                document.getElementById('RoomID-error').textContent = "";
                document.getElementById('CheckInDate-error').textContent = "";
                document.getElementById('CheckOutDate-error').textContent = "";
                //document.getElementById('address-error').textContent = "";
            });
        });
        function submitForm(formData, actionUrl) {
            // Send form data via AJAX
            console.log(actionUrl);
            fetch(actionUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.errors) {
                    // Display errors beneath input fields
                    for (var field in data.errors) {
                        var errorMessage = data.errors[field];
                        console.log(field);
                        document.getElementById("edit-"+ field + "-error").textContent = errorMessage;
                    }
                } else if (data.success) {
                    // Handle success message or take appropriate action
                    //alert(data.success);
                    document.getElementById("save-success").classList.remove('hidden');
                    document.getElementById("save-success").classList.add('flex');
                    setTimeout(function() {
                        document.getElementById("save-success").classList.add('hidden');
                        document.getElementById("save-success").classList.remove('flex');
                        //alert(data.success);
                        location.reload();
                    }, 1000); // 1000 milliseconds delay
                }
            })
            .catch(error => console.error('Error:', error));
        }
        document.getElementById("edit-form").addEventListener("submit", function(event) {
            event.preventDefault(); // Prevent default form submission

            var formData = new FormData(this); // Serialize form data
            var actionUrl = this.action; // Get form action URL

            // Call the submitForm function
            submitForm(formData, actionUrl);
        });


        // Close modal when close button is clicked
        var closeModalButton = document.getElementById('closeModal');
        closeModalButton.addEventListener('click', closeModal);
        //document.getElementById("add-save-success").classList.remove('hidden');
        //document.getElementById("save-success").classList.remove('hidden');
    </script>
</body>

</html>
