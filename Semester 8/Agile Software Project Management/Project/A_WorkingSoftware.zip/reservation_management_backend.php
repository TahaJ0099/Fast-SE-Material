<?php
require_once 'db_connect.php';

class ReservationManager {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    private function sanitize($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    public function addReservation($data) {
        $errors = [];
        
        // Get and sanitize input data
        $guestId = $this->sanitize($data['GuestID'] ?? "");
        $roomId = $this->sanitize($data['RoomID'] ?? "");
        $checkInDate = $this->sanitize($data['CheckInDate'] ?? "");
        $checkOutDate = $this->sanitize($data['CheckOutDate'] ?? "");
        $reservationDate = $this->sanitize($data['ReservationDate'] ?? date("Y-m-d"));

        // Validation
        if (empty($guestId)) $errors['GuestID'] = "Guest ID is required";
        if (empty($roomId)) $errors['RoomID'] = "Room ID is required";
        if (empty($checkInDate)) $errors['CheckInDate'] = "Check-in date is required";
        if (empty($checkOutDate)) $errors['CheckOutDate'] = "Check-out date is required";
        if (!empty($checkInDate) && !empty($checkOutDate) && $checkInDate > $checkOutDate) {
            $errors['date'] = "Check-out date must be after check-in date";
        }

        if (!empty($errors)) {
            echo json_encode(["errors" => $errors]);
            exit();
        }

        $stmt = $this->db->prepare(
            "INSERT INTO reservations (GuestID, RoomID, CheckInDate, CheckOutDate, ReservationDate) VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->bind_param("iisss", $guestId, $roomId, $checkInDate, $checkOutDate, $reservationDate);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => "Reservation added successfully"]);
        } else {
            echo json_encode(["errors" => ["database" => $this->db->error]]);
        }
        $stmt->close();
    }

    public function editReservation($data) {
        $errors = [];
        
        // Get and sanitize input data
        $reservationId = $this->sanitize($data['ReservationID'] ?? "");
        $guestId = $this->sanitize($data['GuestID'] ?? "");
        $roomId = $this->sanitize($data['RoomID'] ?? "");
        $checkInDate = $this->sanitize($data['CheckInDate'] ?? "");
        $checkOutDate = $this->sanitize($data['CheckOutDate'] ?? "");
        $status = $this->sanitize($data['Status'] ?? "Confirmed");

        // Validation
        if (empty($reservationId)) $errors['ReservationID'] = "Reservation ID is required";
        if (empty($guestId)) $errors['GuestID'] = "Guest ID is required";
        if (empty($roomId)) $errors['RoomID'] = "Room ID is required";
        if (empty($checkInDate)) $errors['CheckInDate'] = "Check-in date is required";
        if (empty($checkOutDate)) $errors['CheckOutDate'] = "Check-out date is required";
        if (!empty($checkInDate) && !empty($checkOutDate) && $checkInDate > $checkOutDate) {
            $errors['date'] = "Check-out date must be after check-in date";
        }

        if (!empty($errors)) {
            echo json_encode(["errors" => $errors]);
            exit();
        }

        $stmt = $this->db->prepare(
            "UPDATE reservations SET GuestID=?, RoomID=?, CheckInDate=?, CheckOutDate=?, Status=? WHERE ReservationID=?"
        );
        $stmt->bind_param("iisssi", $guestId, $roomId, $checkInDate, $checkOutDate, $status, $reservationId);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => "Reservation updated successfully"]);
        } else {
            echo json_encode(["errors" => ["database" => $this->db->error]]);
        }
        $stmt->close();
    }
}

// Main execution
header('Content-Type: application/json');

try {
    $dbObj = new Database();
    $reservationManager = new ReservationManager($dbObj->conn);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $action = $_POST["action"] ?? "";
        switch ($action) {
            case "add":
                $reservationManager->addReservation($_POST);
                break;
            case "edit":
                $reservationManager->editReservation($_POST);
                break;
            default:
                echo json_encode(["errors" => ["action" => "Invalid action"]]);
        }
    } else {
        throw new Exception("Invalid request method");
    }
} catch (Exception $e) {
    echo json_encode(["errors" => ["system" => $e->getMessage()]]);
}
?>