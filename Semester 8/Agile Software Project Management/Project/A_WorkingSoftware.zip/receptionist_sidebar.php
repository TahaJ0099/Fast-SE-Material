<!-- Sidebar -->
<aside class="bg-zinc-400 h-screen hidden  text-white w-64 fixed inset-y-0 left-0 flex-shrink-0" id="sidebar">
    <div class="h-full flex flex-col">
        <div class="p-4">
            <!-- Cross Button to Close Sidebar -->
            <button class="text-white focus:outline-none" id="closeSidebar">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 20 20" xmlns="(link unavailable)">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
            <!-- Navigation Links -->
            <ul class="hidden md:flex space-x-6 mr-8">
                <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
                    <a href="/we/admin_dashboard.php" class="font-semibold text-center text-xl">Home</a>
                </li>
                <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
                    <a href="guests.php" class="font-semibold text-xl text-center">Guests</a>
                </li>
                <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
                    <a href="reservation.php" class="font-semibold text-xl">Reservations</a>
                </li>
                <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
                    <a href="billing.php" class="font-semibold text-xl">Bills</a>
                </li>
                <li class="p-3 rounded-xl text-gray-700 hover:bg-slate-900 hover:text-white">
                    <a href="rooms.php" class="font-semibold text-xl">Rooms</a>
                </li>
            </ul>
        </div>
        <div class="flex-grow"></div> <!-- This ensures the sidebar takes up remaining space -->
    </div>
</aside>
