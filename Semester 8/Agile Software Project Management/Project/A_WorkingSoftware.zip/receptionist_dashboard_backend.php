<?php
require_once 'db_connect.php';

class ReceptionistDashboard {
    private $db;

    public function __construct($dbConn) {
        $this->db = $dbConn;
    }

    public function fetchTotalBillData($userId) {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) AS TotalBillsGenerated
             FROM billing b
             JOIN users u ON b.ProcessedBy = u.UserID
             WHERE u.UserID = ?"
        );
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $stmt->close();
        $_SESSION["TotalBillsGenerated"] = $data["TotalBillsGenerated"];
        return $data;
    }

    public function fetchTotalReservationData($userId) {
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) AS TotalReservationsProcessed
             FROM reservations r
             JOIN users u ON r.ProcessedBy = u.UserID
             WHERE u.UserID = ?"
        );
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();
        $stmt->close();
        $_SESSION["TotalReservationsProcessed"] = $data["TotalReservationsProcessed"];
        return $data;
    }
}

// Controller logic
session_start();
$dbObj = new Database();
$dashboard = new ReceptionistDashboard($dbObj->conn);

$userId = $_SESSION["user_id"] ?? null;
if ($userId) {
    $dashboard->fetchTotalBillData($userId);
    $dashboard->fetchTotalReservationData($userId);
    header("Location: ./receptionist_dashboard.php");
    exit();
} else {
    header("Location: index.php");
    exit();
}
?>
