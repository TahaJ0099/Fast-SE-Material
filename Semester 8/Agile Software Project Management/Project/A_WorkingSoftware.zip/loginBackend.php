<?php
require_once 'db_connect.php';

class AuthManager {
    private $db;

    public function __construct($dbConn) {
        session_start();
        $this->db = $dbConn;
    }

    public function login($username, $password) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE Username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if (
                password_verify($password, $user["Password"]) &&
                ($user["Role"] === "Admin" || $user["Role"] === "Receptionist")
            ) {
                $_SESSION["user_id"] = $user["UserID"];
                $_SESSION["role"] = $user["Role"];
                $_SESSION["username"] = $user["Username"];
                if ($user["Role"] === "Admin") {
                    header("Location: admin_dashboard.php");
                } else {
                    header("Location: receptionist_dashboard_backend.php");
                }
                exit();
            }
        }
        $errorMessage = "Invalid username or password.";
        header("Location: index.php?error=" . urlencode($errorMessage));
        exit();
    }
}

// Controller logic
$dbObj = new Database();
$authManager = new AuthManager($dbObj->conn);

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $authManager->login($_POST["username"], $_POST["password"]);
}
?>
