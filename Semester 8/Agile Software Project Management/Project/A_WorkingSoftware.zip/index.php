<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Lodgify Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
    <style>
        #main {
            /* backdrop-filter: blur(80px); /* Adjust the blur intensity as needed */
            /* -webkit-backdrop-filter: blur(8px); For Safari */
            box-shadow: inset 0 0 0 2000px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>

<body class="bg-cover backdrop-blur-sm bg-center" style="background-image: url('login.jpeg')">
    <div id="main" class="h-screen flex items-center justify-center bg-cover backdrop-blur-sm bg-center">
        <!-- Error Modal -->
        <div id="errorModal" class="hidden fixed inset-0 items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-white p-6 rounded-lg shadow-lg max-w-sm">
                <h3 class="text-lg  font-bold mb-2">Error</h3>
                <p id="errorMessage" class=" mb-4">An unexpected error has occurred.</p>
                <button id="closeButton" class="w-full bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                    Close
                </button>
            </div>
        </div>

        <!-- Confirmation Modal -->
        <div id="confirmationModal" class="hidden fixed inset-0 items-center justify-center bg-black bg-opacity-50 z-50">
            <div class="bg-gray-900 p-6 rounded-lg shadow-lg max-w-sm">
                <h3 class="text-lg text-white font-bold mb-2">Signup</h3>
                <p id="confirmationMessage" class="text-white mb-4">Confirmation message</p>
                <button id="confirmationCloseButton" class="w-full bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                    Close
                </button>
            </div>
        </div>

        <div class="container mx-auto p-8 w-3/5 md:w-2/5 lg:w-2/5 xl:w-1/5 rounded-3xl shadow-xl backdrop-blur-xl bg-white/55 flex flex-col items-center justify-center">
            <h1 class="text-3xl font-semibold mb-8 text-center text-black">Lodgify login</h1>
            <form class="mt-4 mb-5 w-full max-w-xs" action="loginBackend.php" method="post">
                <div class="mb-4">
                    <label for="username" class="block text-black font-semibold mb-2">Username:</label>
                    <input type="text" id="username" name="username"
                        class="block w-full px-4 opacity-75 py-2 bg-gray-200 rounded-lg focus:outline-none focus:bg-gray-100"
                        placeholder="Enter your username" required />
                </div>
                <div class="mb-4">
                    <label for="password" class="block text-black font-semibold mb-2">Password:</label>
                    <input type="password" id="password" name="password"
                        class="block w-full px-4 py-2 opacity-75 bg-gray-200 rounded-lg focus:outline-none focus:bg-gray-100"
                        placeholder="Enter your password" required />
                </div>
                <div class="flex flex-col items-center justify-center">
                    <button type="submit"
                        class="w-1/2 mt-2 bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:bg-blue-700">
                        Login
                    </button>
                </div>
            </form>
        </div>

    </div>

    <script src="js/signupScript.js"></script>

    <?php
    if (isset($_GET["success"])) {
        $Message = $_GET["success"];
        // Output JavaScript code to show the modal with the error message
        echo "<script>showConfirmationModal('$Message');</script>";
    }
    if (isset($_GET["error"])) {
        $errorMessage = $_GET["error"];
        // Output JavaScript code to show the modal with the error message
        echo "<script>showModal('$errorMessage');</script>";
    }
    ?>
</body>

</html>
