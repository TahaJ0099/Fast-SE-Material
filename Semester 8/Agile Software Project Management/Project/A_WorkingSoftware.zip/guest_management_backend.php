<?php
require_once 'db_connect.php';

class GuestManager {
    private $db;

    public function __construct($dbConn) {
        $this->db = $dbConn;
    }

    public function sanitize($data) {
        return htmlspecialchars(stripslashes(trim($data)));
    }

    public function validateGuestData($data) {
        $errors = [];
        
        if (empty($data["firstname"])) {
            $errors["firstname"] = "First name is required";
        } elseif (!preg_match("/^[a-zA-Z-' ]*$/", $data["firstname"])) {
            $errors["firstname"] = "Only letters and white space allowed";
        }

        if (empty($data["lastname"])) {
            $errors["lastname"] = "Last name is required";
        } elseif (!preg_match("/^[a-zA-Z-' ]*$/", $data["lastname"])) {
            $errors["lastname"] = "Only letters and white space allowed";
        }

        if (empty($data["email"])) {
            $errors["email"] = "Email is required";
        } elseif (!filter_var($data["email"], FILTER_VALIDATE_EMAIL)) {
            $errors["email"] = "Invalid email format";
        }

        if (empty($data["phone"])) {
            $errors["phone"] = "Phone number is required";
        } elseif (!preg_match("/^\d{11}$/", $data["phone"])) {
            $errors["phone"] = "Phone must be 11 digits";
        }

        if (empty($data["address"])) {
            $errors["address"] = "Address is required";
        }

        return $errors;
    }

    public function addGuest($data) {
        $errors = $this->validateGuestData($data);
        
        if (!empty($errors)) {
            echo json_encode(["errors" => $errors]);
            exit();
        }

        // Store sanitized values in variables
        $firstName = $this->sanitize($data["firstname"]);
        $lastName = $this->sanitize($data["lastname"]);
        $email = $this->sanitize($data["email"]);
        $phone = $this->sanitize($data["phone"]);
        $address = $this->sanitize($data["address"]);

        $stmt = $this->db->prepare("INSERT INTO guests (FirstName, LastName, Email, Phone, Address) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", 
            $firstName,
            $lastName,
            $email,
            $phone,
            $address
        );

        if ($stmt->execute()) {
            echo json_encode(["success" => "Guest added successfully"]);
        } else {
            echo json_encode(["errors" => ["database" => "Failed to add guest"]]);
        }
        $stmt->close();
    }

    public function editGuest($data) {
        $errors = $this->validateGuestData($data);
        
        if (!isset($data["guestId"]) || empty($data["guestId"])) {
            $errors["guestId"] = "Guest ID is required";
        }
    
        if (!empty($errors)) {
            echo json_encode(["errors" => $errors]);
            exit();
        }
    
        // Store sanitized values in variables first
        $firstName = $this->sanitize($data["firstname"]);
        $lastName = $this->sanitize($data["lastname"]);
        $email = $this->sanitize($data["email"]);
        $phone = $this->sanitize($data["phone"]);
        $address = $this->sanitize($data["address"]);
        $guestId = $this->sanitize($data["guestId"]);
    
        $stmt = $this->db->prepare("UPDATE guests SET FirstName=?, LastName=?, Email=?, Phone=?, Address=? WHERE GuestID=?");
        $stmt->bind_param("sssssi", 
            $firstName,
            $lastName,
            $email,
            $phone,
            $address,
            $guestId
        );
    
        if ($stmt->execute()) {
            echo json_encode(["success" => "Guest updated successfully"]);
        } else {
            echo json_encode(["errors" => ["database" => "Failed to update guest"]]);
        }
        $stmt->close();
    }
}

// Main execution
header('Content-Type: application/json');

try {
    $dbObj = new Database();
    $guestManager = new GuestManager($dbObj->conn);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        if (isset($_POST["action"]) && $_POST["action"] === "edit") {
            $guestManager->editGuest($_POST);
        } else {
            $guestManager->addGuest($_POST);
        }
    } else {
        throw new Exception("Invalid request method");
    }
} catch (Exception $e) {
    echo json_encode(["errors" => ["system" => $e->getMessage()]]);
}
?>