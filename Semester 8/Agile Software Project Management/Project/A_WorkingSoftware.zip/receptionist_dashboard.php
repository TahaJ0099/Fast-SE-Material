<!DOCTYPE html>
<html lang="en">
<?php session_start(); ?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Receptionist Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
    <style>
        .dashboard-item {
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            text-decoration: none;
            padding: 20px;
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .dashboard-item:hover {
            transform: translateY(-5px);
        }

        .dashboard-item-icon {
            flex: 0 0 auto;
        }

        .dashboard-item-info {
            flex: 1 1 auto;
            margin-left: 20px;
        }

        .dashboard-item-info span {
            display: block;
            margin-bottom: 5px;
        }

        #sidebar{
            z-index: 10;
        }
        .overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black overlay */
        z-index: 0; /* Place overlay behind other content */
        display: none; /* Initially hidden */
    }
        .overlay.visible {
        display: block; /* Show overlay when explicitly set to visible */
    }
    </style>
</head>

<body class="bg-cover bg-fixed backdrop-blur-sm bg-center" style="background-image: url('login.jpeg')">
    <div class="p-6">
    <?php include "navbar.php"; ?>
    </div>
    <?php include "receptionist_sidebar.php"; ?>
    <main class="flex-1 p-4">
        
        <!-- Overlay to add shadow effect when sidebar is opened -->
        <div class="overlay"></div>

        <!-- Page Content -->
        <div class="py-10">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-gradient-to-l from-slate-500 via-indigo-200 to-zinc-300 overflow-hidden shadow-sm sm:rounded-3xl">
                    <div class="p-10 border-b border-gray-200">
                        <h1 class="font-extrabold text-5xl text-gray-800 mb-6">Welcome, <?php echo $_SESSION[
                            "username"
                        ]; ?></h1>
                        <h1 class="font-bold text-3xl mt-8 text-gray-800 mb-6">Your Score</h1>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Receptionist Dashboard Cards -->
                            <!-- Total Reservations Processed -->
                            <div class="shadow-gray-400 shadow-xl dashboard-item bg-blue-500">
                                <div class="dashboard-item-icon">
                                    <!-- SVG icon for reservations -->
                                    <img src="https://uxwing.com/wp-content/themes/uxwing/download/time-and-date/calendar-color-icon.png" class="h-16 w-16 text-white" alt="Calendar Color Icon">
                                </div>
                                <div class="dashboard-item-info">
                                    <span class="text-white text-3xl font-bold">Reservations</span>
                                    <span class="text-white text-5xl font-bold"><?php echo $_SESSION[
                                        "TotalReservationsProcessed"
                                    ]; ?></span>
                                </div>
                                </div>
                            <!-- Total Bills Generated -->
                            <div class="dashboard-item shadow-gray-400 shadow-xl bg-green-500">
                                <div class="dashboard-item-icon">
                                    <!-- SVG icon for bills -->
                                    <img src="https://www.svgrepo.com/show/525667/bill-check.svg" class="h-20 w-20 text-white" alt="Bill Check Icon">
                                </div>
                                <div class="dashboard-item-info">
                                    <span class="text-white text-3xl font-bold">Bills</span>
                                    <span class="text-white text-5xl font-bold"><?php echo $_SESSION[
                                        "TotalBillsGenerated"
                                    ]; ?></span>
                                </div>
                            </div>
                        </div>
                        <h1 class="font-bold text-3xl mt-8 text-gray-800 mb-6">Available Rooms</h1>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- RoomS Types -->
                            <!-- Fetch and display room types from database -->
                            <?php
                            // Include database connection
                            require_once 'db_connect.php';
                            $db = new Database();
                            $db = $db->conn;        
                            // Fetch room types data from database
                            $query = "SELECT * FROM roomtypes";
                            $result = $db->query($query);

                            // Check if there are any room types
                            if ($result->num_rows > 0) {
                                // Loop through each room type
                                while ($row = $result->fetch_assoc()) { ?>
                                        <div class="dashboard-item shadow-gray-400 shadow-xl bg-gray-100 border border-gray-200 hover:bg-gray-200 rounded-2xl p-6 flex flex-col items-center justify-center transition duration-300">
                                            <!-- Display room type image -->
                                            <img class="w-40 h-40 rounded-xl" src="<?php echo $row[
                                                "ImageURL"
                                            ]; ?>" alt="<?php echo $row[
    "TypeName"
]; ?>" class="h-32 w-32 mb-4">
                                            <!-- Display room type name -->
                                            <h2 class="text-lg font-semibold text-gray-800 mb-2"><?php echo $row[
                                                "TypeName"
                                            ]; ?></h2>
                                            <!-- Display room type description -->
                                            <p class="text-sm text-gray-600"><?php echo $row[
                                                "Description"
                                            ]; ?></p>
                                            <!-- Display room type max occupancy -->
                                            <p class="text-sm text-gray-600">Max Occupancy: <?php echo $row[
                                                "MaxOccupancy"
                                            ]; ?></p>
                                            <!-- Display room type base rate -->
                                            <p class="text-sm text-gray-600">Base Rate: $<?php echo $row[
                                                "BaseRate"
                                            ]; ?></p>
                                        </div>
                                        <?php }
                            } else {
                                // No room types found
                                echo "<p>No room types found.</p>";
                            }

                            // Close database connection
                            $db->close();
                            ?>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    

    <!-- Footer -->
    <footer class="bg-black border-t h-18 border-gray-700">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <p class="text-center text-sm text-gray-100">© 2024 Lodgify All rights reserved.</p>
        </div>
    </footer>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Get the sidebar and the sidebar toggle button
            const closeSidebarToggle = document.getElementById('closeSidebar');
            constsidebar = document.getElementById('sidebar');
            const sidebarToggle = document.getElementById('sidebarToggle');
            const overlay = document.querySelector('.overlay');

            // Add event listener to toggle button
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
                overlay.classList.toggle('visible'); // Toggle overlay visibility
            });
            closeSidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('hidden');
                overlay.classList.toggle('visible'); // Toggle overlay visibility
            });
        });
    </script>
</body>

</html>
