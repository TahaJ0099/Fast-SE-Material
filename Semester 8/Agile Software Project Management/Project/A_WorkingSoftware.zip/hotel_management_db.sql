-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 20, 2024 at 11:08 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_management_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `BillingID` int(11) NOT NULL,
  `ReservationID` int(11) DEFAULT NULL,
  `TotalAmount` decimal(10,2) DEFAULT NULL,
  `PaymentStatus` enum('Paid','Unpaid') DEFAULT NULL,
  `BillingDate` date DEFAULT NULL,
  `ProcessedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `billing`
--

INSERT INTO `billing` (`BillingID`, `ReservationID`, `TotalAmount`, `PaymentStatus`, `BillingDate`, `ProcessedBy`) VALUES
(1, 1, 500.00, 'Paid', '2024-05-05', 2),
(2, 2, 750.00, 'Unpaid', '2024-05-15', 2),
(3, 30, 100.00, 'Unpaid', '2024-05-04', 2),
(4, 31, 100.00, 'Unpaid', '2024-05-04', 2),
(5, 32, 150.00, 'Unpaid', '2024-05-04', 2),
(6, 33, 100.00, 'Unpaid', '2024-05-04', 2),
(7, 34, 100.00, 'Unpaid', '2024-05-04', 2),
(8, 35, 100.00, 'Unpaid', '2024-05-04', 2),
(9, 36, 150.00, 'Unpaid', '2024-05-04', 2),
(10, 37, 1560.00, 'Unpaid', '2024-05-04', 2),
(11, 38, 0.00, 'Unpaid', '2024-05-04', 2),
(12, 39, 100.00, 'Unpaid', '2024-05-04', 2),
(13, 40, 0.00, 'Unpaid', '2024-05-04', 2),
(14, 41, 0.00, 'Unpaid', '2024-05-04', 2),
(15, 42, 0.00, 'Unpaid', '2024-05-04', 2),
(16, 43, 0.00, 'Unpaid', '2024-05-04', 2),
(17, 44, 45.00, 'Unpaid', '2024-05-04', 2),
(18, 45, 145.00, 'Paid', '2024-05-04', 2),
(19, 46, 215.00, 'Unpaid', '2024-05-04', 2),
(20, 47, 1200.00, 'Unpaid', '2024-05-04', 2),
(21, 48, 100.00, 'Unpaid', '2024-05-12', 2),
(22, 49, 100.00, 'Unpaid', '2024-05-12', 2),
(23, 50, 1100.00, 'Unpaid', '2024-05-12', 2),
(24, 51, 1100.00, 'Unpaid', '2024-05-12', 2),
(25, 52, 1100.00, 'Unpaid', '2024-05-12', 2),
(26, 53, 100.00, 'Unpaid', '2024-05-12', 2),
(27, 54, 100.00, 'Unpaid', '2024-05-12', 2),
(28, 55, 100.00, 'Unpaid', '2024-05-12', 2),
(29, 56, 150.00, 'Unpaid', '2024-05-12', 2);

-- --------------------------------------------------------

--
-- Table structure for table `guests`
--

CREATE TABLE `guests` (
  `GuestID` int(11) NOT NULL,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `guests`
--

INSERT INTO `guests` (`GuestID`, `FirstName`, `LastName`, `Email`, `Phone`, `Address`) VALUES
(1, 'John', 'Doe', 'john.doe@example.com', '123-456-7890', '123 Main St, City'),
(2, 'Jane', 'Smith', 'jane.smith@example.com', '456-789-1230', '456 Elm St, Town'),
(3, 'Michael', 'Brown', 'michael.brown@example.com', '555-1234', '123 Main St'),
(4, 'Emma', 'Johnson', 'emma.johnson@example.com', '555-5678', '456 Elm St'),
(5, 'William', 'Davis', 'william.davis@example.com', '555-9012', '789 Oak St'),
(6, 'Andrew', 'Tate', 'andrewTate@example.com', '12345678901', 'Romania'),
(7, 'Bill', 'Jackson', 'BillJack@example.com', '12212313113', 'South Avenue, St. 45'),
(8, 'Syed Sarah', 'Hashmi', 'msohaibakhtar@gmail.com', '03352233822', 'Flat #D6, Noman View, Abul Hassan Isphani Road, Gulshan-e-Iqbal, Karachi'),
(9, 'Tristan', 'Tate', 'Tatebrother@TT.com', '12345678901', 'Romania'),
(10, 'Sohaib', 'Baig', 'msohaibakhtar@gmail.com', '03002233367', 'House# H-5, Sheet# 27 Extension, Model Colony'),
(11, 'Sohaib', 'Baig', 'k213825@nu.edu.pk', '12345678901', 'street 23');

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `ReservationID` int(11) NOT NULL,
  `GuestID` int(11) DEFAULT NULL,
  `RoomID` int(11) DEFAULT NULL,
  `CheckInDate` date DEFAULT NULL,
  `CheckOutDate` date DEFAULT NULL,
  `ReservationDate` date DEFAULT NULL,
  `Status` enum('Confirmed','Cancelled','Checked-In','Checked-Out') DEFAULT NULL,
  `ProcessedBy` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`ReservationID`, `GuestID`, `RoomID`, `CheckInDate`, `CheckOutDate`, `ReservationDate`, `Status`, `ProcessedBy`) VALUES
(1, 1, 1, '2024-05-01', '2024-05-05', '2024-04-25', 'Confirmed', 2),
(2, 2, 2, '2024-05-10', '2024-05-15', '2024-04-28', 'Confirmed', 2),
(3, 1, 1, '2024-05-04', '2024-05-04', '2024-05-04', 'Confirmed', 2),
(23, 3, 2, '2024-05-04', '2024-05-05', '2024-05-04', 'Confirmed', 2),
(24, 3, 2, '2024-05-04', '2024-05-11', '2024-05-04', 'Confirmed', 2),
(25, 1, 1, '2024-05-11', '2024-05-24', '2024-05-04', 'Confirmed', 2),
(30, 1, 1, '2024-05-05', '2024-05-05', '2024-05-04', 'Confirmed', 2),
(31, 1, 1, '2024-05-05', '2024-05-05', '2024-05-04', 'Confirmed', 2),
(32, 1, 2, '2024-05-05', '2024-05-05', '2024-05-04', 'Confirmed', 2),
(33, 1, 1, '2024-05-12', '2024-05-25', '2024-05-04', 'Confirmed', 2),
(34, 1, 1, '2024-05-12', '2024-05-25', '2024-05-04', 'Confirmed', 2),
(35, 1, 2, '2024-05-11', '2024-05-25', '2024-05-04', 'Confirmed', 2),
(36, 1, 1, '2024-05-30', '2024-05-30', '2024-05-04', 'Confirmed', 2),
(37, 3, 2, '2024-05-11', '2024-05-19', '2024-05-04', 'Confirmed', 2),
(38, 3, 2, '2024-05-05', '2024-05-05', '2024-05-04', 'Confirmed', 2),
(39, 1, 1, '2024-05-08', '2024-05-09', '2024-05-04', 'Confirmed', 2),
(40, 1, 1, '2024-05-04', '2024-05-04', '2024-05-04', 'Confirmed', 2),
(41, 1, 1, '2024-05-04', '2024-05-04', '2024-05-04', 'Confirmed', 2),
(42, 1, 1, '2024-05-04', '2024-05-04', '2024-05-04', 'Confirmed', 2),
(43, 1, 1, '2024-05-04', '2024-05-04', '2024-05-04', 'Confirmed', 2),
(44, 1, 1, '2024-05-04', '2024-05-04', '2024-05-04', 'Confirmed', 2),
(45, 1, 1, '2024-05-04', '2024-05-04', '2024-05-04', 'Confirmed', 2),
(46, 3, 1, '2024-05-04', '2024-05-05', '2024-05-04', 'Confirmed', 2),
(47, 3, 2, '2024-05-04', '2024-05-12', '2024-05-04', 'Confirmed', 2),
(48, 1, 1, '2024-05-12', '2024-05-13', '2024-05-12', 'Confirmed', 2),
(49, 1, 1, '2024-05-12', '2024-05-13', '2024-05-12', 'Confirmed', 2),
(50, 1, 1, '2024-05-13', '2024-05-24', '2024-05-12', 'Confirmed', 2),
(51, 1, 1, '2024-05-13', '2024-05-24', '2024-05-12', 'Confirmed', 2),
(52, 1, 1, '2024-05-13', '2024-05-24', '2024-05-12', '', 2),
(53, 1, 1, '2024-05-13', '2024-05-14', '2024-05-12', 'Confirmed', 2),
(54, 1, 1, '2024-05-13', '2024-05-13', '2024-05-12', 'Cancelled', 2),
(55, 1, 1, '2024-05-14', '2024-05-14', '2024-05-12', 'Cancelled', 2),
(56, 1, 2, '2024-05-13', '2024-05-13', '2024-05-12', 'Cancelled', 2);

-- --------------------------------------------------------

--
-- Table structure for table `reservationservices`
--

CREATE TABLE `reservationservices` (
  `ReservationServiceID` int(11) NOT NULL,
  `ReservationID` int(11) DEFAULT NULL,
  `ServiceID` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `TotalPrice` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reservationservices`
--

INSERT INTO `reservationservices` (`ReservationServiceID`, `ReservationID`, `ServiceID`, `Quantity`, `TotalPrice`) VALUES
(1, 1, 1, 2, 30.00),
(2, 1, 3, 4, 80.00),
(3, 2, 2, 1, 10.00),
(4, 2, 3, 3, 60.00),
(10, 46, 1, NULL, 15.00),
(11, 46, 2, NULL, 10.00),
(12, 46, 3, NULL, 20.00),
(13, 37, 1, NULL, 120.00),
(14, 37, 2, NULL, 80.00),
(15, 37, 3, NULL, 160.00),
(16, 45, 1, NULL, 15.00),
(17, 45, 2, NULL, 10.00),
(18, 45, 3, NULL, 20.00),
(19, 44, 1, NULL, 15.00),
(20, 44, 2, NULL, 10.00),
(21, 44, 3, NULL, 20.00);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `RoomID` int(11) NOT NULL,
  `RoomNumber` varchar(20) NOT NULL,
  `Type` varchar(50) DEFAULT NULL,
  `Status` enum('Available','Occupied','Out of Service') DEFAULT NULL,
  `Rate` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`RoomID`, `RoomNumber`, `Type`, `Status`, `Rate`) VALUES
(1, '101', 'Single', 'Available', 100.00),
(2, '102', 'Double', 'Available', 150.00),
(3, '103', 'Suite', 'Available', 200.00);

-- --------------------------------------------------------

--
-- Table structure for table `roomservices`
--

CREATE TABLE `roomservices` (
  `ServiceID` int(11) NOT NULL,
  `ServiceName` varchar(100) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roomservices`
--

INSERT INTO `roomservices` (`ServiceID`, `ServiceName`, `Description`, `Price`) VALUES
(1, 'Breakfast', 'Continental breakfast served in the room.', 15.00),
(2, 'Laundry', 'Laundry service per load.', 10.00),
(3, 'RoomCleaning', 'Daily cleaning service.', 20.00);

-- --------------------------------------------------------

--
-- Table structure for table `roomtypes`
--

CREATE TABLE `roomtypes` (
  `TypeID` int(11) NOT NULL,
  `TypeName` varchar(50) DEFAULT NULL,
  `Description` text DEFAULT NULL,
  `MaxOccupancy` int(11) DEFAULT NULL,
  `BaseRate` decimal(10,2) DEFAULT NULL,
  `ImageURL` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roomtypes`
--

INSERT INTO `roomtypes` (`TypeID`, `TypeName`, `Description`, `MaxOccupancy`, `BaseRate`, `ImageURL`) VALUES
(1, 'Single', 'Standard single room with one bed.', 1, 100.00, 'uploads/single.jpg'),
(2, 'Double', 'Standard double room with two beds.', 2, 150.00, 'uploads/double.jpg'),
(3, 'Suite', 'Luxury suite with separate living area and bedroom.', 2, 200.00, 'uploads/suite.jpg'),
(4, 'Sea Facing', 'Room with a view of the sea.', 2, 180.00, 'uploads/sea-facing.jpeg'),
(5, 'Family', 'Spacious room suitable for families.', 4, 250.00, 'uploads/family.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserID` int(11) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Role` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UserID`, `Username`, `Password`, `Email`, `Role`) VALUES
(1, 'admin', '$2y$10$27Fv3wVzwWX7C6aNv.fja.d0rcFBrxO.ECCAFn4bZmnly5.Vmj7T6', 'admin@example.com', 'Admin'),
(2, 'rcp', '$2y$10$/kYW3rasOd3GrrGKkxAwGeXqhk8C8chw5Z44QPoqbi7xNX2ocvwQe', 'receptionist1@example.com', 'Receptionist'),
(3, 'receptionist2', 'receptionistpassword', 'receptionist2@example.com', 'Receptionist');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`BillingID`),
  ADD KEY `ReservationID` (`ReservationID`),
  ADD KEY `ProcessedBy` (`ProcessedBy`);

--
-- Indexes for table `guests`
--
ALTER TABLE `guests`
  ADD PRIMARY KEY (`GuestID`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`ReservationID`),
  ADD KEY `GuestID` (`GuestID`),
  ADD KEY `RoomID` (`RoomID`),
  ADD KEY `ProcessedBy` (`ProcessedBy`);

--
-- Indexes for table `reservationservices`
--
ALTER TABLE `reservationservices`
  ADD PRIMARY KEY (`ReservationServiceID`),
  ADD KEY `ReservationID` (`ReservationID`),
  ADD KEY `ServiceID` (`ServiceID`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`RoomID`);

--
-- Indexes for table `roomservices`
--
ALTER TABLE `roomservices`
  ADD PRIMARY KEY (`ServiceID`);

--
-- Indexes for table `roomtypes`
--
ALTER TABLE `roomtypes`
  ADD PRIMARY KEY (`TypeID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billing`
--
ALTER TABLE `billing`
  MODIFY `BillingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `guests`
--
ALTER TABLE `guests`
  MODIFY `GuestID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `ReservationID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `reservationservices`
--
ALTER TABLE `reservationservices`
  MODIFY `ReservationServiceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `RoomID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roomservices`
--
ALTER TABLE `roomservices`
  MODIFY `ServiceID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roomtypes`
--
ALTER TABLE `roomtypes`
  MODIFY `TypeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `billing`
--
ALTER TABLE `billing`
  ADD CONSTRAINT `billing_ibfk_1` FOREIGN KEY (`ReservationID`) REFERENCES `reservations` (`ReservationID`),
  ADD CONSTRAINT `billing_ibfk_2` FOREIGN KEY (`ProcessedBy`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `reservations_ibfk_1` FOREIGN KEY (`GuestID`) REFERENCES `guests` (`GuestID`),
  ADD CONSTRAINT `reservations_ibfk_2` FOREIGN KEY (`RoomID`) REFERENCES `rooms` (`RoomID`),
  ADD CONSTRAINT `reservations_ibfk_3` FOREIGN KEY (`ProcessedBy`) REFERENCES `users` (`UserID`);

--
-- Constraints for table `reservationservices`
--
ALTER TABLE `reservationservices`
  ADD CONSTRAINT `reservationservices_ibfk_1` FOREIGN KEY (`ReservationID`) REFERENCES `reservations` (`ReservationID`),
  ADD CONSTRAINT `reservationservices_ibfk_2` FOREIGN KEY (`ServiceID`) REFERENCES `roomservices` (`ServiceID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
