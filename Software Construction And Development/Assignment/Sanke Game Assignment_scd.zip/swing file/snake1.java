package Snake;

import javax.swing.*;

public class snake1 extends JFrame {
    snake1() {
        Gamepanel gamePanel = new Gamepanel();
        add(gamePanel);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setUndecorated(true);
        pack();
        setVisible(true);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        new snake1();
    }
}
