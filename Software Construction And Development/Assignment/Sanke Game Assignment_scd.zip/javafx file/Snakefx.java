package com.example.javafx;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Snakefx extends Application {
    private static final int SCREEN_WIDTH = 600;
    private static final int SCREEN_HEIGHT = 600;
    private static final int UNIT_SIZE = 25;
    private static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / UNIT_SIZE;
    private static final int DELAY = 10;
    private static final int INITIAL_BODY_PARTS = 6;

    private final List<Integer> x = new ArrayList<>();
    private final List<Integer> y = new ArrayList<>();
    private int applex;
    private int appley;
    private int appleeaten;
    private char direction = 'R';
    private boolean running = false;
    private AnimationTimer animationTimer;
    private final Random random = new Random();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Pane root = new Pane();
        Canvas canvas = new Canvas(SCREEN_WIDTH, SCREEN_HEIGHT);
        root.getChildren().add(canvas);

        Scene scene = new Scene(root, SCREEN_WIDTH, SCREEN_HEIGHT);
        scene.setOnKeyPressed(event -> {
            KeyCode code = event.getCode();
            if (code == KeyCode.LEFT && direction != 'R') {
                direction = 'L';
            } else if (code == KeyCode.RIGHT && direction != 'L') {
                direction = 'R';
            } else if (code == KeyCode.UP && direction != 'D') {
                direction = 'U';
            } else if (code == KeyCode.DOWN && direction != 'U') {
                direction = 'D';
            }
        });

        GraphicsContext gc = canvas.getGraphicsContext2D();
        animationTimer = new AnimationTimer() {
            long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (now - lastUpdate >= 1000000000 / DELAY) {
                    move();
                    checkApple();
                    checkCollision();
                    draw(gc);
                    lastUpdate = now;
                }
            }
        };

        primaryStage.setScene(scene);
        primaryStage.setTitle("Snake Game");
        primaryStage.setResizable(false);
        primaryStage.show();

        startGame();
    }

    public void startGame() {
        newApple();
        running = true;
        x.clear();
        y.clear();
        for (int i = 0; i < INITIAL_BODY_PARTS; i++) {
            x.add(0);
            y.add(0);
        }
        animationTimer.start();
    }

    public void newApple() {
        applex = random.nextInt((int) (SCREEN_WIDTH / UNIT_SIZE)) * UNIT_SIZE;
        appley = random.nextInt((int) (SCREEN_HEIGHT / UNIT_SIZE)) * UNIT_SIZE;
    }

    public void move() {
        for (int i = x.size() - 1; i > 0; i--) {
            x.set(i, x.get(i - 1));
            y.set(i, y.get(i - 1));
        }

        switch (direction) {
            case 'U':
                y.set(0, y.get(0) - UNIT_SIZE);
                break;
            case 'D':
                y.set(0, y.get(0) + UNIT_SIZE);
                break;
            case 'L':
                x.set(0, x.get(0) - UNIT_SIZE);
                break;
            case 'R':
                x.set(0, x.get(0) + UNIT_SIZE);
                break;
        }
    }

    public void checkApple() {
        if (x.get(0) == applex && y.get(0) == appley) {
            appleeaten++;
            x.add(0);
            y.add(0);
            newApple();
        }
    }

    public void checkCollision() {
        if (x.get(0) < 0 || x.get(0) >= SCREEN_WIDTH || y.get(0) < 0 || y.get(0) >= SCREEN_HEIGHT) {
            running = false;
        }

        for (int i = 1; i < x.size(); i++) {
            if (x.get(0).equals(x.get(i)) && y.get(0).equals(y.get(i))) {
                running = false;
                break;
            }
        }

        if (!running) {
            animationTimer.stop();
        }
    }

    public void draw(GraphicsContext gc) {
        if (running) {
            gc.clearRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

            for (int i = 0; i < SCREEN_HEIGHT / UNIT_SIZE; i++) {
                gc.setStroke(Color.WHITE);
                gc.strokeLine(i * UNIT_SIZE, 0, i * UNIT_SIZE, SCREEN_HEIGHT);
                gc.strokeLine(0, i * UNIT_SIZE, SCREEN_WIDTH, i * UNIT_SIZE);
            }

            gc.setFill(Color.RED);
            gc.fillOval(applex, appley, UNIT_SIZE, UNIT_SIZE);

            for (int i = 0; i < x.size(); i++) {
                if (i == 0) {
                    gc.setFill(Color.BLUE);
                    gc.fillRect(x.get(i), y.get(i), UNIT_SIZE, UNIT_SIZE);
                } else {
                    gc.setFill(Color.GRAY);
                    gc.fillRect(x.get(i), y.get(i), UNIT_SIZE, UNIT_SIZE);
                }
            }

            gc.setFill(Color.RED);
            gc.setFont(new javafx.scene.text.Font("Ink Free", 35));
            gc.fillText("Score: " + appleeaten, 10, 30);
        } else {
            gc.setFill(Color.RED);
            gc.setFont(new javafx.scene.text.Font("Ink Free", 75));
            gc.fillText("Game Over", 100, SCREEN_HEIGHT / 2);
        }
    }
}
